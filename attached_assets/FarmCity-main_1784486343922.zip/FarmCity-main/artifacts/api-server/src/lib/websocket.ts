import { WebSocketServer, WebSocket } from "ws";
import { type IncomingMessage } from "http";
import { verifyToken } from "./auth";
import { db } from "@workspace/db";
import { chatMessagesTable, playerPositionsTable, avatarsTable, playersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "./logger";

interface GameClient {
  ws: WebSocket;
  playerId: number;
  username: string;
  posX: number;
  posY: number;
}

const clients = new Map<number, GameClient>();

export function createWebSocketServer(server: import("http").Server): WebSocketServer {
  const wss = new WebSocketServer({ server, path: "/ws" });

  wss.on("connection", async (ws: WebSocket, req: IncomingMessage) => {
    const url = new URL(req.url ?? "", `http://${req.headers.host}`);
    const token = url.searchParams.get("token");

    if (!token) {
      ws.close(1008, "Token requerido");
      return;
    }

    const payload = verifyToken(token);
    if (!payload) {
      ws.close(1008, "Token inválido");
      return;
    }

    const { playerId, username } = payload;

    // Get initial position
    const [pos] = await db.select().from(playerPositionsTable).where(eq(playerPositionsTable.playerId, playerId)).limit(1);
    const posX = pos?.posX ?? Math.floor(Math.random() * 10);
    const posY = pos?.posY ?? Math.floor(Math.random() * 10);

    // Mark online
    await db.update(playersTable).set({ isOnline: true }).where(eq(playersTable.id, playerId));

    // Get avatar
    const [avatar] = await db.select().from(avatarsTable).where(eq(avatarsTable.playerId, playerId)).limit(1);

    const client: GameClient = { ws, playerId, username, posX, posY };
    clients.set(playerId, client);

    logger.info({ playerId, username }, "WebSocket player connected");

    // Notify others: player joined
    const playerSummary = {
      id: playerId,
      username,
      posX,
      posY,
      avatar: avatar ?? undefined,
    };

    broadcast({ type: "player_joined", player: playerSummary }, playerId);

    // Send current players list to new client
    const currentPlayers = Array.from(clients.values())
      .filter((c) => c.playerId !== playerId)
      .map((c) => ({ id: c.playerId, username: c.username, posX: c.posX, posY: c.posY }));

    safeSend(ws, { type: "players_update", players: currentPlayers });

    ws.on("message", async (data) => {
      try {
        const msg = JSON.parse(data.toString()) as { type: string; posX?: number; posY?: number; message?: string };

        if (msg.type === "move" && typeof msg.posX === "number" && typeof msg.posY === "number") {
          client.posX = msg.posX;
          client.posY = msg.posY;

          // Persist position
          const existing = await db.select().from(playerPositionsTable).where(eq(playerPositionsTable.playerId, playerId)).limit(1);
          if (existing.length) {
            await db.update(playerPositionsTable).set({ posX: msg.posX, posY: msg.posY }).where(eq(playerPositionsTable.playerId, playerId));
          } else {
            await db.insert(playerPositionsTable).values({ playerId, posX: msg.posX, posY: msg.posY });
          }

          broadcast({ type: "player_moved", playerId, posX: msg.posX, posY: msg.posY }, playerId);
        } else if (msg.type === "chat" && typeof msg.message === "string" && msg.message.trim()) {
          const text = msg.message.trim().slice(0, 200);

          const [saved] = await db.insert(chatMessagesTable).values({ playerId, message: text }).returning();
          if (!saved) return;

          const chatMsg = {
            id: saved.id,
            playerId,
            username,
            message: text,
            createdAt: saved.createdAt.toISOString(),
            avatarSkinColor: avatar?.skinColor ?? null,
            avatarHairColor: avatar?.hairColor ?? null,
            avatarShirtColor: avatar?.shirtColor ?? null,
          };

          broadcastAll({ type: "chat_message", message: chatMsg });
        }
      } catch (err) {
        logger.error({ err }, "WebSocket message error");
      }
    });

    ws.on("close", async () => {
      clients.delete(playerId);
      await db.update(playersTable).set({ isOnline: false }).where(eq(playersTable.id, playerId));
      broadcast({ type: "player_left", playerId }, playerId);
      logger.info({ playerId, username }, "WebSocket player disconnected");
    });

    ws.on("error", (err) => {
      logger.error({ err, playerId }, "WebSocket error");
    });
  });

  return wss;
}

function safeSend(ws: WebSocket, data: unknown): void {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(data));
  }
}

function broadcast(data: unknown, excludePlayerId?: number): void {
  clients.forEach((client) => {
    if (client.playerId !== excludePlayerId) {
      safeSend(client.ws, data);
    }
  });
}

function broadcastAll(data: unknown): void {
  clients.forEach((client) => {
    safeSend(client.ws, data);
  });
}
