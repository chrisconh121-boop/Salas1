import '../farmcity-panels/farmcity.css';

// ── Pixel art bottom nav icons ────────────────────────────────────────────────
const NAV_ITEMS = [
  { emoji: '💬', label: 'Chat',      active: false },
  { emoji: '🎒', label: 'Inventario',active: false },
  { emoji: '🏡', label: 'Mi Casa',   active: false },
  { emoji: '🔨', label: 'Construir', active: false },
  { emoji: '🛒', label: 'Tienda',    active: false },
  { emoji: '👥', label: 'Amigos',    active: false },
];

// ── Simulated isometric floor tiles (CSS-only background) ────────────────────
function IsoBackground() {
  return (
    <div className="absolute inset-0" style={{
      background: 'linear-gradient(160deg, #1a3d1a 0%, #2d5a1e 40%, #1e4a2a 70%, #0f2a14 100%)',
      overflow: 'hidden',
    }}>
      {/* Fake isometric grid lines */}
      <svg className="absolute inset-0 w-full h-full opacity-10" preserveAspectRatio="none">
        <defs>
          <pattern id="iso" x="0" y="0" width="64" height="32" patternUnits="userSpaceOnUse">
            <path d="M0 16 L32 0 L64 16 L32 32 Z" fill="none" stroke="#fff" strokeWidth="0.5"/>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#iso)" />
      </svg>
      {/* Stone plaza area */}
      <div className="absolute" style={{
        left: '30%', top: '35%',
        width: 260, height: 130,
        background: 'rgba(160,160,150,0.28)',
        clipPath: 'polygon(50% 0%, 100% 25%, 50% 50%, 0% 25%)',
        transform: 'scaleY(1.2)',
      }} />
      {/* Fountain silhouette */}
      <div className="absolute" style={{ left: '47%', top: '42%' }}>
        <div style={{ width: 28, height: 28, background: 'rgba(80,160,220,0.5)', borderRadius: '50%' }} />
        <div className="absolute" style={{ top: -14, left: 11, width: 6, height: 18, background: 'rgba(180,180,190,0.6)' }} />
      </div>
      {/* Trees */}
      {[[12,52],[18,62],[75,48],[82,58],[8,38],[20,40]].map(([l,t], i) => (
        <div key={i} className="absolute" style={{ left: `${l}%`, top: `${t}%` }}>
          <div style={{ width: 18, height: 24, background: '#1a5c0a', clipPath: 'polygon(50% 0%, 100% 100%, 0% 100%)', marginBottom: -6, marginLeft: 3 }} />
          <div style={{ width: 6, height: 8, background: '#5C3810', marginLeft: 9 }} />
        </div>
      ))}
      {/* Character placeholder */}
      <div className="absolute" style={{ left: '48%', top: '52%', width: 20, height: 32 }}>
        <svg width="20" height="32" viewBox="0 0 16 16" style={{ imageRendering: 'pixelated' }}>
          <rect x="5" y="14" width="2" height="1" fill="#2A2A2A"/>
          <rect x="9" y="14" width="2" height="1" fill="#2A2A2A"/>
          <rect x="5" y="10" width="3" height="5" fill="#1A3A8F"/>
          <rect x="8" y="10" width="3" height="5" fill="#1A3A8F"/>
          <rect x="4" y="6"  width="8" height="5" fill="#2A2A2A"/>
          <rect x="2" y="6"  width="2" height="4" fill="#2A2A2A"/>
          <rect x="12" y="6" width="2" height="4" fill="#2A2A2A"/>
          <rect x="2" y="10" width="2" height="1" fill="#FDDBB4"/>
          <rect x="12" y="10" width="2" height="1" fill="#FDDBB4"/>
          <rect x="7" y="5"  width="2" height="1" fill="#FDDBB4"/>
          <rect x="5" y="1"  width="6" height="5" fill="#FDDBB4"/>
          <rect x="5" y="1"  width="6" height="2" fill="#2C1503"/>
          <rect x="6" y="3"  width="1" height="1" fill="#111"/>
          <rect x="9" y="3"  width="1" height="1" fill="#111"/>
        </svg>
        {/* Move target diamond */}
        <div className="absolute" style={{ bottom: -6, left: -2, width: 24, height: 12,
          border: '2px solid rgba(255,255,255,0.7)',
          clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)',
        }}/>
      </div>
    </div>
  );
}

// ── Currency chip ─────────────────────────────────────────────────────────────
function Chip({ icon, value, color }: { icon: string; value: string; color: string }) {
  return (
    <div className="flex items-center gap-1 px-2 py-1" style={{
      background: 'rgba(0,0,0,0.55)',
      border: `2px solid ${color}`,
      minWidth: 70,
    }}>
      <span className="text-sm leading-none">{icon}</span>
      <span className="font-['VT323'] text-white text-base leading-none">{value}</span>
      <span className="font-['VT323'] text-xs leading-none ml-auto" style={{ color }}>+</span>
    </div>
  );
}

// ── Nav button ────────────────────────────────────────────────────────────────
function NavBtn({ emoji, label, active }: { emoji: string; label: string; active: boolean }) {
  return (
    <button className="flex flex-col items-center justify-center gap-0.5 flex-1 py-2 relative" style={{
      background: active ? 'rgba(255,200,50,0.18)' : 'transparent',
      borderTop: active ? '3px solid #F5C518' : '3px solid transparent',
    }}>
      <span className="text-xl leading-none">{emoji}</span>
      <span className="font-['VT323'] text-xs leading-none" style={{ color: active ? '#F5C518' : 'rgba(255,255,255,0.7)' }}>
        {label}
      </span>
      {label === 'Chat' && (
        <div className="absolute top-1 right-1 w-4 h-4 rounded-full bg-red-500 flex items-center justify-center">
          <span className="font-['VT323'] text-white text-xs leading-none">3</span>
        </div>
      )}
    </button>
  );
}

// ── Main export ───────────────────────────────────────────────────────────────
export function FarmCityHUD() {
  return (
    <div className="relative w-full h-screen overflow-hidden select-none" style={{ fontFamily: "'VT323', monospace" }}>
      {/* Game world */}
      <IsoBackground />

      {/* ── TOP BAR ─────────────────────────────────────────────────────── */}
      <div className="absolute top-0 left-0 right-0 z-20 flex items-center gap-2 px-2 pt-2 pb-1"
        style={{ background: 'linear-gradient(to bottom, rgba(0,0,0,0.7) 0%, transparent 100%)' }}>

        {/* Logo */}
        <div className="flex-shrink-0 mr-1">
          <div className="font-['VT323'] leading-none" style={{ fontSize: 22, color: '#F5C518',
            textShadow: '2px 2px 0 #8B4513, -1px -1px 0 #8B4513' }}>
            FARM<br/>CITY
          </div>
        </div>

        {/* Currency row */}
        <div className="flex gap-1.5 flex-1">
          <Chip icon="🪙" value="25,350" color="#F5C518" />
          <Chip icon="💎" value="320"    color="#60A5FA" />
          <Chip icon="🌿" value="1,250"  color="#4ADE80" />
        </div>

        {/* Social icons */}
        <div className="flex gap-1 flex-shrink-0">
          {['👥','✉️','⚙️'].map(ic => (
            <button key={ic} className="w-8 h-8 flex items-center justify-center text-lg"
              style={{ background: 'rgba(0,0,0,0.5)', border: '2px solid rgba(255,255,255,0.25)' }}>
              {ic}
            </button>
          ))}
        </div>
      </div>

      {/* ── PLAYER CARD (top-left, below top bar) ──────────────────────── */}
      <div className="absolute left-2 z-20" style={{ top: 56 }}>
        <div className="flex items-center gap-2 px-2 py-1.5"
          style={{ background: 'rgba(10,6,2,0.78)', border: '2px solid #7A4F1E', minWidth: 130 }}>
          {/* Avatar */}
          <div style={{ width: 32, height: 32, background: '#C8E6B0', border: '2px solid #3D2010', flexShrink: 0, display:'flex', alignItems:'center', justifyContent:'center' }}>
            <svg width="28" height="28" viewBox="0 0 16 16" style={{ imageRendering: 'pixelated' }}>
              <rect x="5" y="14" width="2" height="1" fill="#2A2A2A"/>
              <rect x="9" y="14" width="2" height="1" fill="#2A2A2A"/>
              <rect x="5" y="10" width="3" height="5" fill="#1A3A8F"/>
              <rect x="8" y="10" width="3" height="5" fill="#1A3A8F"/>
              <rect x="4" y="6"  width="8" height="5" fill="#2A2A2A"/>
              <rect x="2" y="6"  width="2" height="4" fill="#2A2A2A"/>
              <rect x="12" y="6" width="2" height="4" fill="#2A2A2A"/>
              <rect x="2" y="10" width="2" height="1" fill="#FDDBB4"/>
              <rect x="12" y="10" width="2" height="1" fill="#FDDBB4"/>
              <rect x="7" y="5"  width="2" height="1" fill="#FDDBB4"/>
              <rect x="5" y="1"  width="6" height="5" fill="#FDDBB4"/>
              <rect x="5" y="1"  width="6" height="2" fill="#2C1503"/>
              <rect x="6" y="3"  width="1" height="1" fill="#111"/>
              <rect x="9" y="3"  width="1" height="1" fill="#111"/>
            </svg>
          </div>
          {/* Info */}
          <div className="flex flex-col">
            <span className="font-['VT323'] text-white text-base leading-tight">Chris</span>
            <span className="font-['VT323'] text-xs leading-tight" style={{ color: '#D4A96A' }}>Nivel 15</span>
            {/* XP bar */}
            <div className="mt-0.5" style={{ width: 72, height: 5, background: '#2A1A0A', border: '1px solid #7A4F1E' }}>
              <div style={{ width: '62%', height: '100%', background: '#F5C518' }} />
            </div>
          </div>
        </div>
      </div>

      {/* ── NOTIFICATION (top-right, KekoCIty-style) ────────────────────── */}
      <div className="absolute right-2 z-20 flex flex-col gap-1" style={{ top: 56 }}>
        <div className="flex items-center gap-2 px-2 py-1"
          style={{ background: 'rgba(10,6,2,0.78)', border: '2px solid #3D6B3D' }}>
          <div className="w-2 h-2 rounded-full bg-green-400"/>
          <span className="font-['VT323'] text-white text-sm leading-none">FarmTest se conectó</span>
        </div>
      </div>

      {/* ── BOTTOM AREA ─────────────────────────────────────────────────── */}
      <div className="absolute bottom-0 left-0 right-0 z-20">
        {/* Chat input */}
        <div className="flex items-center gap-2 px-3 py-2"
          style={{ background: 'rgba(10,6,2,0.82)', borderTop: '2px solid #3D2010' }}>
          <div className="flex-1 flex items-center gap-2 px-3 py-1.5"
            style={{ background: 'rgba(255,255,255,0.08)', border: '2px solid rgba(255,255,255,0.2)' }}>
            <span className="text-base">💬</span>
            <span className="font-['VT323'] text-base leading-none" style={{ color: 'rgba(255,255,255,0.4)' }}>
              Haz clic para chatear...
            </span>
          </div>
          <button className="px-3 py-1.5 font-['VT323'] text-white text-base"
            style={{ background: '#2E7D32', border: '2px solid #4CAF50' }}>
            ▶
          </button>
        </div>

        {/* Nav bar */}
        <div className="flex items-stretch" style={{ background: 'rgba(6,3,1,0.92)', borderTop: '3px solid #3D2010' }}>
          {NAV_ITEMS.map(item => <NavBtn key={item.label} {...item} />)}
        </div>
      </div>
    </div>
  );
}
