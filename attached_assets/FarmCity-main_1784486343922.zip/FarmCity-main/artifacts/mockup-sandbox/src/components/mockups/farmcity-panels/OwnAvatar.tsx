import './farmcity.css';

const SKIN = '#FDDBB4';
const SHIRT = '#3CB371';
const PANTS = '#4169E1';
const HAIR = '#2C1503';

function PixelCharacter({ scale = 3 }: { scale?: number }) {
  const S = scale;
  const W = 16 * S;
  const H = 16 * S;

  return (
    <svg width={W} height={H} viewBox={`0 0 16 16`} style={{ imageRendering: 'pixelated' }}>
      {/* Shadow */}
      <ellipse cx="8" cy="15.5" rx="5" ry="1.5" fill="rgba(0,0,0,0.2)" />
      {/* Shoes */}
      <rect x="5" y="14" width="2" height="1" fill="#2A2A2A" />
      <rect x="9" y="14" width="2" height="1" fill="#2A2A2A" />
      {/* Pants */}
      <rect x="5" y="10" width="3" height="5" fill={PANTS} />
      <rect x="8" y="10" width="3" height="5" fill={PANTS} />
      {/* Shirt */}
      <rect x="4" y="6" width="8" height="5" fill={SHIRT} />
      {/* Arms */}
      <rect x="2" y="6" width="2" height="4" fill={SHIRT} />
      <rect x="12" y="6" width="2" height="4" fill={SHIRT} />
      {/* Hands */}
      <rect x="2" y="10" width="2" height="1" fill={SKIN} />
      <rect x="12" y="10" width="2" height="1" fill={SKIN} />
      {/* Neck */}
      <rect x="7" y="5" width="2" height="1" fill={SKIN} />
      {/* Head */}
      <rect x="5" y="1" width="6" height="5" fill={SKIN} />
      {/* Hair */}
      <rect x="5" y="1" width="6" height="2" fill={HAIR} />
      <rect x="5" y="1" width="1" height="3" fill={HAIR} />
      {/* Eyes */}
      <rect x="6" y="3" width="1" height="1" fill="#111" />
      <rect x="9" y="3" width="1" height="1" fill="#111" />
    </svg>
  );
}

function StatBar({ value, max, color }: { value: number; max: number; color: string }) {
  const pct = Math.round((value / max) * 100);
  return (
    <div className="flex-1 h-3 bg-[#E8D5AA] border border-[#3D2010] overflow-hidden pixel-stat-bar">
      <div className="h-full transition-all" style={{ width: `${pct}%`, background: color }} />
    </div>
  );
}

const ACTIONS = [
  { emoji: '🏡', label: 'Mi Granja' },
  { emoji: '🎒', label: 'Inventario' },
  { emoji: '👗', label: 'Cambiar ropa' },
  { emoji: '💃', label: 'Bailar' },
  { emoji: '😄', label: 'Emociones' },
  { emoji: '🪑', label: 'Sentarse' },
  { emoji: '📷', label: 'Fotografía' },
  { emoji: '⚙️', label: 'Config.' },
];

export function OwnAvatar() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#1a0f05]/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-[340px] flex flex-col shadow-2xl" style={{ border: '4px solid #3D2010', background: '#FFF8E7' }}>

        {/* ── Header bar ── */}
        <div className="flex items-center justify-between px-3 py-2" style={{ background: '#7A4F1E', borderBottom: '4px solid #3D2010' }}>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-400" />
            <span className="font-['VT323'] text-white text-xl tracking-widest uppercase">Chris</span>
          </div>
          <button className="font-['VT323'] text-white text-xl leading-none hover:text-yellow-300 transition-colors px-1" style={{ border: '2px solid rgba(255,255,255,0.4)', minWidth: 24, textAlign: 'center' }}>
            ✕
          </button>
        </div>

        {/* ── Avatar + identity ── */}
        <div className="flex items-center gap-4 px-4 py-4" style={{ borderBottom: '3px solid #D4A96A' }}>
          {/* Avatar frame */}
          <div className="flex-shrink-0 flex items-center justify-center" style={{ width: 72, height: 72, background: '#C8E6B0', border: '3px solid #3D2010' }}>
            <PixelCharacter scale={4} />
          </div>
          <div className="flex flex-col gap-0.5">
            <span className="font-['VT323'] text-2xl text-[#3D2010] leading-tight">CHRIS</span>
            <div className="flex items-center gap-2">
              <span className="font-['VT323'] text-base text-[#7A4F1E]">Nivel</span>
              <span className="font-['VT323'] text-xl text-[#3D2010] leading-tight">12</span>
            </div>
            <span className="font-['VT323'] text-base text-[#5C7A3A]">🌾 Granjero</span>
          </div>
          {/* XP bar */}
          <div className="ml-auto flex flex-col items-end gap-1">
            <span className="font-['VT323'] text-xs text-[#7A4F1E]">EXP</span>
            <div className="w-16 h-2 bg-[#E8D5AA] border border-[#3D2010]">
              <div className="h-full bg-[#F5A623]" style={{ width: '62%' }} />
            </div>
            <span className="font-['VT323'] text-xs text-[#7A4F1E]">620/1000</span>
          </div>
        </div>

        {/* ── Stats ── */}
        <div className="px-4 py-3 flex flex-col gap-2" style={{ borderBottom: '3px solid #D4A96A', background: '#FFFDF5' }}>
          {/* HP */}
          <div className="flex items-center gap-2">
            <span className="text-sm w-4">❤️</span>
            <span className="font-['VT323'] text-sm text-[#7A4F1E] w-8">Vida</span>
            <StatBar value={80} max={100} color="#E74C3C" />
            <span className="font-['VT323'] text-xs text-[#7A4F1E] w-12 text-right">80/100</span>
          </div>
          {/* Gold */}
          <div className="flex items-center gap-2">
            <span className="text-sm w-4">🪙</span>
            <span className="font-['VT323'] text-sm text-[#7A4F1E] w-8">Oro</span>
            <span className="font-['VT323'] text-lg text-[#C5A028] flex-1">1,240</span>
            <div className="flex items-center gap-1">
              <span className="text-xs">💎</span>
              <span className="font-['VT323'] text-lg text-[#9B59B6]">45</span>
            </div>
          </div>
        </div>

        {/* ── Actions grid ── */}
        <div className="p-3 grid grid-cols-2 gap-2">
          {ACTIONS.map(({ emoji, label }) => (
            <button
              key={label}
              className="flex items-center gap-2 px-2 py-2 text-left hover:bg-[#F5E6C8] active:translate-y-px transition-all"
              style={{ border: '2px solid #3D2010', background: '#FFF8E7' }}
            >
              <span className="text-base leading-none">{emoji}</span>
              <span className="font-['VT323'] text-sm text-[#3D2010] leading-tight">{label}</span>
            </button>
          ))}
        </div>

        {/* ── Close full ── */}
        <div className="px-3 pb-3">
          <button
            className="w-full py-2 font-['VT323'] text-base text-white tracking-widest uppercase hover:opacity-90 active:translate-y-px transition-all"
            style={{ background: '#3D2010', border: '2px solid #1A0A02' }}
          >
            Cerrar panel
          </button>
        </div>
      </div>
    </div>
  );
}
