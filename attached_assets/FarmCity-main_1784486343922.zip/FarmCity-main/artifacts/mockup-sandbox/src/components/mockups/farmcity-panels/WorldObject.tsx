import './farmcity.css';

interface Action {
  emoji: string;
  label: string;
  desc: string;
  color: string;
  disabled?: boolean;
}

const FOUNTAIN_ACTIONS: Action[] = [
  { emoji: '👀', label: 'Inspeccionar',  desc: 'Ver detalles del objeto',       color: '#3D2010' },
  { emoji: '💧', label: 'Beber agua',    desc: 'Restaura +10 de vida',          color: '#2980B9' },
  { emoji: '📷', label: 'Fotografiar',   desc: 'Tomar foto del objeto',         color: '#8E44AD' },
  { emoji: '💬', label: 'Historia',      desc: 'Conoce el origen del objeto',   color: '#5C7A3A' },
  { emoji: '✨', label: 'Desear',        desc: 'Lanza una moneda al agua',       color: '#D4A017' },
  { emoji: 'ℹ️', label: 'Información',   desc: 'Estadísticas del objeto',       color: '#7A4F1E' },
];

function FountainIllustration() {
  return (
    <div className="relative flex items-center justify-center" style={{ width: 80, height: 80 }}>
      {/* Base */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2" style={{ width: 70, height: 16, background: '#8E8E9A', border: '2px solid #5A5A6A', borderRadius: 2 }} />
      {/* Pool water */}
      <div className="absolute" style={{ bottom: 8, left: '50%', transform: 'translateX(-50%)', width: 52, height: 12, background: '#5B9BD5', border: '1px solid #3A7ABF', borderRadius: 2 }} />
      {/* Pillar */}
      <div className="absolute" style={{ bottom: 20, left: '50%', transform: 'translateX(-50%)', width: 10, height: 30, background: '#ABABBA', border: '1px solid #8A8A9A' }} />
      {/* Top bowl */}
      <div className="absolute" style={{ bottom: 46, left: '50%', transform: 'translateX(-50%)', width: 28, height: 10, background: '#8E8E9A', border: '2px solid #5A5A6A', borderRadius: 2 }} />
      {/* Water top */}
      <div className="absolute" style={{ bottom: 50, left: '50%', transform: 'translateX(-50%)', width: 18, height: 8, background: 'rgba(100,180,255,0.85)', borderRadius: 4 }} />
      {/* Sparkle */}
      <div className="absolute top-0 right-3 text-xs">✨</div>
    </div>
  );
}

export function WorldObject() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#1a0f05]/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-[340px] flex flex-col shadow-2xl" style={{ border: '4px solid #3D2010', background: '#FFF8E7' }}>

        {/* ── Header ── */}
        <div className="flex items-center justify-between px-3 py-2" style={{ background: '#4A6741', borderBottom: '4px solid #3D2010' }}>
          <div className="flex items-center gap-2">
            <span className="text-sm">🏛️</span>
            <span className="font-['VT323'] text-white text-xl tracking-widest uppercase">Fuente Central</span>
          </div>
          <button className="font-['VT323'] text-white text-xl leading-none px-1 hover:text-yellow-300 transition-colors" style={{ border: '2px solid rgba(255,255,255,0.4)', minWidth: 24, textAlign: 'center' }}>
            ✕
          </button>
        </div>

        {/* ── Object info ── */}
        <div className="flex items-center gap-4 px-4 py-3" style={{ borderBottom: '3px solid #D4A96A', background: '#FFFDF5' }}>
          <FountainIllustration />
          <div className="flex flex-col gap-1">
            <span className="font-['VT323'] text-xl text-[#3D2010] leading-tight">Fuente Central</span>
            <span className="font-['VT323'] text-sm text-[#7A4F1E]">Decoración Histórica</span>
            <div className="flex gap-2 mt-1 flex-wrap">
              <span className="font-['VT323'] text-xs px-1" style={{ background: '#E8F5E9', border: '1px solid #81C784', color: '#2E7D32' }}>
                📍 Plaza Central
              </span>
              <span className="font-['VT323'] text-xs px-1" style={{ background: '#FFF3CD', border: '1px solid #FFD54F', color: '#7A4F1E' }}>
                ⭐ Nivel 3
              </span>
            </div>
          </div>
        </div>

        {/* ── Object description ── */}
        <div className="px-4 py-2" style={{ borderBottom: '2px solid #D4A96A', background: '#FFFAEF' }}>
          <p className="font-['VT323'] text-sm text-[#7A4F1E] leading-snug">
            La fuente más antigua de FarmCity. Dicen que quien lanza una moneda y pide un deseo, lo verá cumplido antes de la próxima cosecha.
          </p>
        </div>

        {/* ── Compatible actions ── */}
        <div className="p-3 flex flex-col gap-2">
          <span className="font-['VT323'] text-xs text-[#7A4F1E] uppercase tracking-widest px-1">Acciones disponibles</span>
          {FOUNTAIN_ACTIONS.map(({ emoji, label, desc, color, disabled }) => (
            <button
              key={label}
              disabled={disabled}
              className="flex items-center gap-3 w-full px-3 py-2 text-left transition-all hover:opacity-90 active:translate-y-px disabled:opacity-40 disabled:cursor-not-allowed"
              style={{ border: '2px solid #3D2010', background: disabled ? '#F0E8D8' : '#FFF8E7' }}
            >
              <span className="text-base w-5 text-center leading-none flex-shrink-0">{emoji}</span>
              <div className="flex flex-col flex-1 min-w-0">
                <span className="font-['VT323'] text-base leading-tight" style={{ color }}>{label}</span>
                <span className="font-['VT323'] text-xs text-[#A0856A] leading-tight truncate">{desc}</span>
              </div>
              {!disabled && <span className="font-['VT323'] text-[#D4A96A] text-xs flex-shrink-0">▶</span>}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
