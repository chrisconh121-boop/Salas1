import './farmcity.css';

const SKIN2  = '#C68642';
const SHIRT2 = '#E74C3C';
const PANTS2 = '#2C3E50';
const HAIR2  = '#1A1A1A';

function PixelCharacter2({ scale = 3 }: { scale?: number }) {
  const S = scale;
  return (
    <svg width={16 * S} height={16 * S} viewBox="0 0 16 16" style={{ imageRendering: 'pixelated' }}>
      <ellipse cx="8" cy="15.5" rx="5" ry="1.5" fill="rgba(0,0,0,0.2)" />
      <rect x="5" y="14" width="2" height="1" fill="#2A2A2A" />
      <rect x="9" y="14" width="2" height="1" fill="#2A2A2A" />
      <rect x="5" y="10" width="3" height="5" fill={PANTS2} />
      <rect x="8" y="10" width="3" height="5" fill={PANTS2} />
      <rect x="4" y="6" width="8" height="5" fill={SHIRT2} />
      <rect x="2" y="6" width="2" height="4" fill={SHIRT2} />
      <rect x="12" y="6" width="2" height="4" fill={SHIRT2} />
      <rect x="2" y="10" width="2" height="1" fill={SKIN2} />
      <rect x="12" y="10" width="2" height="1" fill={SKIN2} />
      <rect x="7" y="5" width="2" height="1" fill={SKIN2} />
      <rect x="5" y="1" width="6" height="5" fill={SKIN2} />
      <rect x="5" y="1" width="6" height="2" fill={HAIR2} />
      <rect x="5" y="1" width="1" height="4" fill={HAIR2} />
      <rect x="10" y="1" width="1" height="2" fill={HAIR2} />
      <rect x="6" y="3" width="1" height="1" fill="#111" />
      <rect x="9" y="3" width="1" height="1" fill="#111" />
    </svg>
  );
}

const ACTIONS = [
  { emoji: '👤', label: 'Ver perfil',       color: '#5C7A3A' },
  { emoji: '➕', label: 'Agregar amigo',    color: '#2980B9' },
  { emoji: '✉️', label: 'Mensaje privado',   color: '#7A4F1E' },
  { emoji: '🔄', label: 'Intercambiar',     color: '#8E44AD' },
  { emoji: '👥', label: 'Invitar a grupo',  color: '#27AE60' },
  { emoji: '🏡', label: 'Visitar granja',   color: '#D4A017' },
  { emoji: '🚩', label: 'Reportar',         color: '#C0392B' },
  { emoji: '🚫', label: 'Bloquear',         color: '#7F8C8D' },
];

export function OtherPlayer() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#1a0f05]/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-[320px] flex flex-col shadow-2xl" style={{ border: '4px solid #3D2010', background: '#FFF8E7' }}>

        {/* ── Header ── */}
        <div className="flex items-center justify-between px-3 py-2" style={{ background: '#7A4F1E', borderBottom: '4px solid #3D2010' }}>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-400" />
            <span className="font-['VT323'] text-white text-xl tracking-widest uppercase">Jugador123</span>
          </div>
          <button className="font-['VT323'] text-white text-xl leading-none px-1 hover:text-yellow-300 transition-colors" style={{ border: '2px solid rgba(255,255,255,0.4)', minWidth: 24, textAlign: 'center' }}>
            ✕
          </button>
        </div>

        {/* ── Player identity ── */}
        <div className="flex items-center gap-4 px-4 py-3" style={{ borderBottom: '3px solid #D4A96A', background: '#FFFDF5' }}>
          <div className="flex-shrink-0 flex items-center justify-center" style={{ width: 60, height: 60, background: '#D4E6F8', border: '3px solid #3D2010' }}>
            <PixelCharacter2 scale={3} />
          </div>
          <div className="flex flex-col">
            <span className="font-['VT323'] text-xl text-[#3D2010]">JUGADOR123</span>
            <div className="flex items-center gap-2">
              <span className="font-['VT323'] text-sm text-[#7A4F1E]">Nivel 8</span>
              <span className="text-[#D4A96A]">•</span>
              <span className="font-['VT323'] text-sm text-[#5C7A3A]">⛏️ Minero</span>
            </div>
            <div className="flex gap-2 mt-1">
              <span className="font-['VT323'] text-xs px-1" style={{ background: '#F5E6C8', border: '1px solid #D4A96A', color: '#7A4F1E' }}>
                🏅 Top 50
              </span>
              <span className="font-['VT323'] text-xs px-1" style={{ background: '#E8F5E9', border: '1px solid #81C784', color: '#2E7D32' }}>
                Activo hoy
              </span>
            </div>
          </div>
        </div>

        {/* ── Actions list ── */}
        <div className="p-3 flex flex-col gap-2">
          {ACTIONS.map(({ emoji, label, color }) => (
            <button
              key={label}
              className="flex items-center gap-3 w-full px-3 py-2 text-left hover:opacity-90 active:translate-y-px transition-all"
              style={{ border: '2px solid #3D2010', background: '#FFF8E7' }}
            >
              <span className="text-base w-5 text-center leading-none flex-shrink-0">{emoji}</span>
              <span className="font-['VT323'] text-base leading-tight flex-1" style={{ color }}>
                {label}
              </span>
              <span className="font-['VT323'] text-[#D4A96A] text-xs">▶</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
