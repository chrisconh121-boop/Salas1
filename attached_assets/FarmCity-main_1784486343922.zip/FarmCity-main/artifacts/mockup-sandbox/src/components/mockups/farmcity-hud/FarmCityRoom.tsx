import '../farmcity-panels/farmcity.css';

// ── Isometric room drawn in SVG ───────────────────────────────────────────────
function IsoRoom({ w, h }: { w: number; h: number }) {
  // Room corners in isometric space
  // Floor: a diamond / rhombus
  const floorW = w * 0.82;
  const floorH = h * 0.48;
  const cx = w / 2;
  const floorTop = h * 0.18;

  // Floor diamond
  const fl = { x: cx,            y: floorTop };            // top
  const fr = { x: cx + floorW/2, y: floorTop + floorH/2 }; // right
  const fb = { x: cx,            y: floorTop + floorH };   // bottom
  const fll= { x: cx - floorW/2, y: floorTop + floorH/2 }; // left

  // Wall height
  const wallH = h * 0.3;

  // Back-left wall (left face)
  const wlTL = { x: fl.x - floorW/2, y: fl.y - wallH };   // top-left of wall
  const wlTR = { x: fl.x,            y: fl.y - wallH };    // top-right = floor top
  const wlBR = fl;
  const wlBL = fll;

  // Back-right wall (right face)
  const wrTL = { x: fl.x,            y: fl.y - wallH };
  const wrTR = { x: fl.x + floorW/2, y: fl.y - wallH };
  const wrBR = fr;
  const wrBL = fl;

  const poly = (pts: {x:number;y:number}[]) =>
    pts.map(p => `${p.x},${p.y}`).join(' ');

  // Wood floor tile grid lines (simplified)
  const floorLines: string[] = [];
  const STEPS = 5;
  for (let i = 1; i < STEPS; i++) {
    const t = i / STEPS;
    // Lines parallel to left diagonal
    const lx1 = fl.x  + (fr.x - fl.x) * t;
    const ly1 = fl.y  + (fr.y - fl.y) * t;
    const lx2 = fll.x + (fb.x - fll.x) * t;
    const ly2 = fll.y + (fb.y - fll.y) * t;
    floorLines.push(`M${lx1},${ly1} L${lx2},${ly2}`);
    // Lines parallel to right diagonal
    const rx1 = fl.x  + (fll.x - fl.x) * t;
    const ry1 = fl.y  + (fll.y - fl.y) * t;
    const rx2 = fr.x  + (fb.x - fr.x) * t;
    const ry2 = fr.y  + (fb.y - fr.y) * t;
    floorLines.push(`M${rx1},${ry1} L${rx2},${ry2}`);
  }

  // Window on right wall
  const winX = (wrTL.x + wrTR.x) / 2 + 20;
  const winY = (wrTL.y + wrBL.y) / 2 - 10;

  // Furniture: sofa (left area of floor)
  const sofaCX = fll.x + (fl.x - fll.x) * 0.3 + (fb.x - fll.x) * 0.25;
  const sofaCY = fll.y + (fl.y - fll.y) * 0.3 + (fb.y - fll.y) * 0.25;

  // Plant (right wall corner area)
  const plantX = fr.x - (fr.x - fl.x) * 0.15;
  const plantY = fr.y - (fr.y - fl.y) * 0.15 - 30;

  // Character
  const charX = cx + 10;
  const charY = floorTop + floorH * 0.55;

  return (
    <svg width={w} height={h} style={{ display: 'block' }}>
      {/* Sky / background gradient */}
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#0a0a14"/>
          <stop offset="100%" stopColor="#1a1020"/>
        </linearGradient>
        <linearGradient id="floorGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#5C3A1E"/>
          <stop offset="100%" stopColor="#3D2010"/>
        </linearGradient>
        <linearGradient id="leftWall" x1="1" y1="0" x2="0" y2="0">
          <stop offset="0%" stopColor="#D4B896"/>
          <stop offset="100%" stopColor="#B89870"/>
        </linearGradient>
        <linearGradient id="rightWall" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#C8A878"/>
          <stop offset="100%" stopColor="#A88858"/>
        </linearGradient>
      </defs>
      <rect width={w} height={h} fill="url(#sky)"/>

      {/* ── Walls ── */}
      {/* Left wall */}
      <polygon points={poly([wlTL, wlTR, wlBR, wlBL])} fill="url(#leftWall)"/>
      <polygon points={poly([wlTL, wlTR, wlBR, wlBL])} fill="none" stroke="#8B6A42" strokeWidth="1.5"/>
      {/* Wallpaper / wainscoting on left wall */}
      <polygon
        points={poly([
          { x: wlBL.x + (wlTL.x - wlBL.x) * 0.28, y: wlBL.y + (wlTL.y - wlBL.y) * 0.28 },
          { x: wlBR.x + (wlTR.x - wlBR.x) * 0.28, y: wlBR.y + (wlTR.y - wlBR.y) * 0.28 },
          wlBR, wlBL,
        ])}
        fill="#B89060" opacity="0.4"
      />

      {/* Right wall */}
      <polygon points={poly([wrTL, wrTR, wrBR, wrBL])} fill="url(#rightWall)"/>
      <polygon points={poly([wrTL, wrTR, wrBR, wrBL])} fill="none" stroke="#7A5830" strokeWidth="1.5"/>
      {/* Wainscoting on right wall */}
      <polygon
        points={poly([
          { x: wrBL.x + (wrTL.x - wrBL.x) * 0.28, y: wrBL.y + (wrTL.y - wrBL.y) * 0.28 },
          { x: wrBR.x + (wrTR.x - wrBR.x) * 0.28, y: wrBR.y + (wrTR.y - wrBR.y) * 0.28 },
          wrBR, wrBL,
        ])}
        fill="#8B6030" opacity="0.4"
      />

      {/* Window on right wall */}
      <rect x={winX - 22} y={winY - 18} width={44} height={36} fill="#1a3a6a" stroke="#8B6030" strokeWidth="2"/>
      <rect x={winX - 22} y={winY - 18} width={44} height={36} fill="none" stroke="#C8A060" strokeWidth="1" strokeDasharray="2,2"/>
      <line x1={winX} y1={winY - 18} x2={winX} y2={winY + 18} stroke="#C8A060" strokeWidth="1"/>
      <line x1={winX - 22} y1={winY} x2={winX + 22} y2={winY} stroke="#C8A060" strokeWidth="1"/>
      {/* Window glow */}
      <rect x={winX - 20} y={winY - 16} width={40} height={32} fill="rgba(100,160,255,0.12)"/>

      {/* ── Floor ── */}
      <polygon points={poly([fl, fr, fb, fll])} fill="url(#floorGrad)"/>
      {floorLines.map((d, i) => (
        <path key={i} d={d} stroke="rgba(0,0,0,0.25)" strokeWidth="0.8" fill="none"/>
      ))}
      <polygon points={poly([fl, fr, fb, fll])} fill="none" stroke="#2A1208" strokeWidth="1.5"/>

      {/* ── Rug ── */}
      <polygon
        points={poly([
          { x: cx - 20,    y: floorTop + floorH * 0.40 },
          { x: cx + 40,    y: floorTop + floorH * 0.52 },
          { x: cx + 20,    y: floorTop + floorH * 0.68 },
          { x: cx - 40,    y: floorTop + floorH * 0.56 },
        ])}
        fill="rgba(160,60,40,0.55)" stroke="rgba(200,80,60,0.6)" strokeWidth="1.5"
      />

      {/* ── Sofa ── */}
      <g transform={`translate(${sofaCX - 28}, ${sofaCY - 10})`}>
        {/* seat */}
        <polygon points="0,10 28,0 56,10 28,20" fill="#2E7D32" stroke="#1B5E20" strokeWidth="1.5"/>
        {/* back */}
        <polygon points="0,10 0,-8 28,-18 28,0" fill="#388E3C" stroke="#1B5E20" strokeWidth="1"/>
        <polygon points="28,0 28,-18 56,-8 56,10" fill="#2E7D32" stroke="#1B5E20" strokeWidth="1"/>
        {/* armrests */}
        <polygon points="0,-8 6,-12 6,6 0,10" fill="#43A047" stroke="#1B5E20" strokeWidth="1"/>
        <polygon points="50,-12 56,-8 56,10 50,6" fill="#388E3C" stroke="#1B5E20" strokeWidth="1"/>
      </g>

      {/* ── Plant (right) ── */}
      <g transform={`translate(${plantX}, ${plantY})`}>
        <rect x="-6" y="14" width="12" height="10" fill="#5D3A1A" stroke="#3D2010" strokeWidth="1"/>
        <circle cx="0" cy="8"  r="10" fill="#2E7D32" stroke="#1B5E20" strokeWidth="1"/>
        <circle cx="-7" cy="4" r="7"  fill="#388E3C" stroke="#1B5E20" strokeWidth="1"/>
        <circle cx="7"  cy="4" r="7"  fill="#2E7D32" stroke="#1B5E20" strokeWidth="1"/>
        <circle cx="0"  cy="0" r="6"  fill="#43A047" stroke="#1B5E20" strokeWidth="1"/>
      </g>

      {/* ── Small table ── */}
      <g transform={`translate(${cx + 40}, ${floorTop + floorH * 0.42})`}>
        <polygon points="0,-4 20,4 0,12 -20,4" fill="#6D4C1E" stroke="#3D2010" strokeWidth="1"/>
        <polygon points="0,-4 0,-16 20,-8 20,4" fill="#7A5528" stroke="#3D2010" strokeWidth="1"/>
        <polygon points="-20,-8 0,-16 0,-4 -20,4" fill="#5A3A10" stroke="#3D2010" strokeWidth="1"/>
      </g>

      {/* ── Character ── */}
      <g transform={`translate(${charX - 8}, ${charY - 32})`}>
        {/* shadow */}
        <ellipse cx="8" cy="32" rx="9" ry="4" fill="rgba(0,0,0,0.35)"/>
        {/* shoes */}
        <rect x="3" y="29" width="3" height="2" fill="#1A1A1A"/>
        <rect x="9" y="29" width="3" height="2" fill="#1A1A1A"/>
        {/* pants */}
        <rect x="3" y="21" width="4" height="9" fill="#1A3A8F"/>
        <rect x="8" y="21" width="4" height="9" fill="#1A3A8F"/>
        {/* shirt */}
        <rect x="2" y="13" width="11" height="9" fill="#111"/>
        <rect x="0" y="13" width="3" height="7" fill="#111"/>
        <rect x="12" y="13" width="3" height="7" fill="#111"/>
        {/* hands */}
        <rect x="0" y="20" width="3" height="2" fill="#FDDBB4"/>
        <rect x="12" y="20" width="3" height="2" fill="#FDDBB4"/>
        {/* neck+head */}
        <rect x="6" y="11" width="3" height="2" fill="#FDDBB4"/>
        <rect x="4" y="3"  width="7" height="9" fill="#FDDBB4"/>
        {/* hair */}
        <rect x="4" y="3"  width="7" height="3" fill="#2C1503"/>
        <rect x="4" y="3"  width="2" height="5" fill="#2C1503"/>
        {/* eyes */}
        <rect x="6" y="7"  width="1" height="1" fill="#111"/>
        <rect x="9" y="7"  width="1" height="1" fill="#111"/>
        {/* Click diamond */}
        <polygon points="8,35 14,39 8,43 2,39" fill="none" stroke="rgba(255,255,255,0.6)" strokeWidth="1.5"/>
      </g>
    </svg>
  );
}

// ── Top info bar ──────────────────────────────────────────────────────────────
function TopBar() {
  return (
    <div className="absolute top-0 left-0 right-0 z-10 flex items-center gap-2 px-3 py-2"
      style={{ background: 'linear-gradient(to bottom, rgba(0,0,0,0.78) 70%, transparent)' }}>
      {/* Owner / room name */}
      <div className="flex items-center gap-1.5">
        <div style={{ width: 28, height: 28, background: '#C8E6B0', border: '2px solid #3D2010', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg width="24" height="24" viewBox="0 0 16 16" style={{ imageRendering: 'pixelated' }}>
            <rect x="4" y="9"  width="3" height="5" fill="#1A3A8F"/>
            <rect x="8" y="9"  width="3" height="5" fill="#1A3A8F"/>
            <rect x="3" y="5"  width="9" height="5" fill="#111"/>
            <rect x="5" y="1"  width="5" height="5" fill="#FDDBB4"/>
            <rect x="5" y="1"  width="5" height="2" fill="#2C1503"/>
          </svg>
        </div>
        <div className="flex flex-col">
          <span className="font-['VT323'] text-white text-base leading-none">Propietario: Chris</span>
          <span className="font-['VT323'] text-xs leading-none" style={{ color: '#D4A96A' }}>Sala Principal</span>
        </div>
      </div>

      <div className="flex-1"/>

      {/* Currency */}
      <div className="flex items-center gap-1 px-2 py-1" style={{ background: 'rgba(0,0,0,0.5)', border: '2px solid #F5C518' }}>
        <span className="text-sm">🪙</span>
        <span className="font-['VT323'] text-white text-base leading-none">1,240</span>
      </div>
      <div className="flex items-center gap-1 px-2 py-1" style={{ background: 'rgba(0,0,0,0.5)', border: '2px solid #60A5FA' }}>
        <span className="text-sm">💎</span>
        <span className="font-['VT323'] text-white text-base leading-none">45</span>
      </div>
    </div>
  );
}

// ── Bottom navigation ─────────────────────────────────────────────────────────
interface BtnProps { emoji: string; label: string; badge?: number; accent?: string }

function NavBtn({ emoji, label, badge, accent = '#F5C518' }: BtnProps) {
  return (
    <button className="flex flex-col items-center justify-center gap-1 flex-1 py-3 relative"
      style={{ borderTop: `3px solid transparent` }}>
      <div className="relative">
        <span className="text-2xl leading-none">{emoji}</span>
        {badge != null && (
          <div className="absolute -top-1 -right-2 w-4 h-4 rounded-full flex items-center justify-center"
            style={{ background: '#E53935', border: '1px solid #B71C1C' }}>
            <span className="font-['VT323'] text-white leading-none" style={{ fontSize: 9 }}>{badge}</span>
          </div>
        )}
      </div>
      <span className="font-['VT323'] text-xs leading-none" style={{ color: 'rgba(255,255,255,0.8)' }}>
        {label}
      </span>
    </button>
  );
}

// ── Chat bubble ───────────────────────────────────────────────────────────────
function ChatBar() {
  return (
    <div className="flex items-center gap-2 px-3 py-2"
      style={{ background: 'rgba(6,3,1,0.9)', borderTop: '2px solid #2A1A0A' }}>
      <div className="flex-1 flex items-center gap-2 px-3 py-2"
        style={{ background: 'rgba(255,255,255,0.07)', border: '2px solid rgba(255,255,255,0.15)' }}>
        <span className="text-sm">💬</span>
        <span className="font-['VT323'] text-base" style={{ color: 'rgba(255,255,255,0.38)' }}>
          Decir...
        </span>
      </div>
      <button className="w-9 h-9 flex items-center justify-center text-lg"
        style={{ background: '#1B5E20', border: '2px solid #2E7D32' }}>
        ▶
      </button>
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export function FarmCityRoom() {
  // Compute at render time based on viewport
  const W = 390;
  const H = 600;

  return (
    <div className="flex flex-col h-screen overflow-hidden select-none"
      style={{ background: '#0a0a14', maxWidth: 390, margin: '0 auto' }}>

      {/* Room fills remaining space */}
      <div className="relative flex-1 overflow-hidden">
        <IsoRoom w={W} h={H} />
        <TopBar />

        {/* Online badge */}
        <div className="absolute right-3 bottom-6 z-10 flex items-center gap-1.5 px-2 py-1"
          style={{ background: 'rgba(0,0,0,0.7)', border: '2px solid #2E7D32' }}>
          <div className="w-2 h-2 rounded-full bg-green-400"/>
          <span className="font-['VT323'] text-white text-sm leading-none">8 conectados</span>
        </div>
      </div>

      {/* Chat input */}
      <ChatBar />

      {/* Bottom nav — the 4 key buttons */}
      <div className="flex items-stretch"
        style={{ background: 'rgba(8,4,1,0.97)', borderTop: '3px solid #3D2010' }}>
        <NavBtn emoji="🏠" label="Crear Sala" />
        <NavBtn emoji="🎒" label="Inventario" />
        <NavBtn emoji="📬" label="Solicitudes" badge={3} />
        <NavBtn emoji="⚙️" label="Ajustes" />
      </div>
    </div>
  );
}
