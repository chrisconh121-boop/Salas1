import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-background">
      <div className="pixel-panel text-center max-w-md w-full">
        <h1 className="text-6xl font-bold text-destructive mb-4">404</h1>
        <p className="text-xl mb-6">Página no encontrada.</p>
        <Link href="/" className="pixel-btn block w-full">
          Volver al Inicio
        </Link>
      </div>
    </div>
  );
}
