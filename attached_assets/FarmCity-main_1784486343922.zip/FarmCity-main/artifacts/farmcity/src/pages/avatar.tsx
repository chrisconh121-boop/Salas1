import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/contexts/auth-context';
import { useGetAvatarOptions, useCreateAvatar, getGetAvatarOptionsQueryKey } from '@workspace/api-client-react';
import { useLanguage } from '@/contexts/language-context';
import { PixelAvatar } from '@/components/pixel-avatar';
import { useQueryClient } from '@tanstack/react-query';
import { getGetMeQueryKey } from '@workspace/api-client-react';

export default function AvatarCreator() {
  const [, setLocation] = useLocation();
  const { t } = useLanguage();
  const { token, player, setPlayer } = useAuth();
  const queryClient = useQueryClient();

  const { data: options, isLoading: optionsLoading } = useGetAvatarOptions({
    query: { enabled: !!token, queryKey: getGetAvatarOptionsQueryKey() }
  });

  const createAvatar = useCreateAvatar();

  const [skinColor, setSkinColor] = useState('#ffccaa');
  const [hairColor, setHairColor] = useState('#8b4513');
  const [hairStyle, setHairStyle] = useState('short');
  const [shirtColor, setShirtColor] = useState('#3cb371');
  const [pantsColor, setPantsColor] = useState('#4169e1');

  useEffect(() => {
    if (options) {
      if (options.skinColors.length) setSkinColor(options.skinColors[0]);
      if (options.hairColors.length) setHairColor(options.hairColors[0]);
      if (options.hairStyles.length) setHairStyle(options.hairStyles[0]);
      if (options.shirtColors.length) setShirtColor(options.shirtColors[0]);
      if (options.pantColors.length) setPantsColor(options.pantColors[0]);
    }
  }, [options]);

  useEffect(() => {
    // If the user already has an avatar, prefill it
    if (player?.avatar) {
      setSkinColor(player.avatar.skinColor);
      setHairColor(player.avatar.hairColor);
      setHairStyle(player.avatar.hairStyle);
      setShirtColor(player.avatar.shirtColor);
      setPantsColor(player.avatar.pantsColor);
    }
  }, [player]);

  const handleFinish = () => {
    createAvatar.mutate({
      data: {
        skinColor,
        hairColor,
        hairStyle,
        shirtColor,
        pantsColor,
        hatStyle: null,
        accessory: null
      }
    }, {
      onSuccess: (avatarData) => {
        if (player) {
          const updatedPlayer = { ...player, avatar: avatarData };
          setPlayer(updatedPlayer);
          queryClient.setQueryData(getGetMeQueryKey(), updatedPlayer);
        }
        setLocation('/plaza');
      }
    });
  };

  if (!token) {
    setLocation('/');
    return null;
  }

  if (optionsLoading || !options) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center text-2xl font-bold">
        {t('loading')}
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] w-full flex items-center justify-center bg-secondary relative overflow-hidden p-4">
      {/* Wood pattern background */}
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{
        backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 10px, rgba(0,0,0,0.5) 10px, rgba(0,0,0,0.5) 12px)'
      }}></div>

      <div className="pixel-panel z-10 w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Left Side: Avatar Preview */}
        <div className="flex flex-col items-center justify-center bg-background border-4 border-border p-8 min-h-[300px]">
          <h2 className="text-3xl font-bold mb-8 text-center">{t('avatar_creator')}</h2>
          
          <div className="bg-white border-4 border-foreground p-4 mb-8 shadow-md">
            <PixelAvatar 
              skinColor={skinColor}
              hairColor={hairColor}
              shirtColor={shirtColor}
              pantsColor={pantsColor}
              hairStyle={hairStyle}
              scale={12}
            />
          </div>

          <button 
            onClick={handleFinish}
            disabled={createAvatar.isPending}
            className="pixel-btn w-full max-w-xs"
            data-testid="button-finish-avatar"
          >
            {t('finish_avatar')}
          </button>
        </div>

        {/* Right Side: Options */}
        <div className="space-y-6 overflow-y-auto max-h-[70vh] pr-4">
          
          <div>
            <label className="block text-xl font-bold mb-2">{t('skin_color')}</label>
            <div className="flex flex-wrap gap-2">
              {options.skinColors.map(color => (
                <button
                  key={color}
                  onClick={() => setSkinColor(color)}
                  className={`w-12 h-12 border-4 ${skinColor === color ? 'border-foreground shadow-md scale-110' : 'border-border'}`}
                  style={{ backgroundColor: color }}
                  data-testid={`skin-${color}`}
                  aria-label="Skin Color"
                />
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xl font-bold mb-2">{t('hair_style')}</label>
            <div className="flex flex-wrap gap-2">
              {options.hairStyles.map(style => (
                <button
                  key={style}
                  onClick={() => setHairStyle(style)}
                  className={`px-4 py-2 border-4 text-xl capitalize ${hairStyle === style ? 'border-foreground bg-primary text-white shadow-md' : 'border-border bg-background'}`}
                  data-testid={`hair-style-${style}`}
                >
                  {style}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xl font-bold mb-2">{t('hair_color')}</label>
            <div className="flex flex-wrap gap-2">
              {options.hairColors.map(color => (
                <button
                  key={color}
                  onClick={() => setHairColor(color)}
                  className={`w-12 h-12 border-4 ${hairColor === color ? 'border-foreground shadow-md scale-110' : 'border-border'}`}
                  style={{ backgroundColor: color }}
                  data-testid={`hair-${color}`}
                  aria-label="Hair Color"
                />
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xl font-bold mb-2">{t('shirt_color')}</label>
            <div className="flex flex-wrap gap-2">
              {options.shirtColors.map(color => (
                <button
                  key={color}
                  onClick={() => setShirtColor(color)}
                  className={`w-12 h-12 border-4 ${shirtColor === color ? 'border-foreground shadow-md scale-110' : 'border-border'}`}
                  style={{ backgroundColor: color }}
                  data-testid={`shirt-${color}`}
                  aria-label="Shirt Color"
                />
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xl font-bold mb-2">{t('pants_color')}</label>
            <div className="flex flex-wrap gap-2">
              {options.pantColors.map(color => (
                <button
                  key={color}
                  onClick={() => setPantsColor(color)}
                  className={`w-12 h-12 border-4 ${pantsColor === color ? 'border-foreground shadow-md scale-110' : 'border-border'}`}
                  style={{ backgroundColor: color }}
                  data-testid={`pants-${color}`}
                  aria-label="Pants Color"
                />
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
