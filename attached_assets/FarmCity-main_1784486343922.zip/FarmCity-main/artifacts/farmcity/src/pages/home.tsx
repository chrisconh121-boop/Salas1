import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/contexts/auth-context';
import { useLogin, useRegister } from '@workspace/api-client-react';
import { useLanguage } from '@/contexts/language-context';

export default function Home() {
  const [, setLocation] = useLocation();
  const { t } = useLanguage();
  const { token, player, setToken, setPlayer } = useAuth();
  
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const loginMutation = useLogin();
  const registerMutation = useRegister();

  // Redirection logic
  useEffect(() => {
    if (token && player) {
      if (player.avatar) {
        setLocation('/plaza');
      } else {
        setLocation('/avatar');
      }
    }
  }, [token, player, setLocation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (isLogin) {
      loginMutation.mutate({ data: { username, password } }, {
        onSuccess: (res) => {
          setToken(res.token);
          setPlayer(res.player);
        },
        onError: () => {
          setErrorMsg(t('error_login'));
        }
      });
    } else {
      registerMutation.mutate({ data: { username, password } }, {
        onSuccess: (res) => {
          setToken(res.token);
          setPlayer(res.player);
        },
        onError: () => {
          setErrorMsg(t('error_register'));
        }
      });
    }
  };

  // If already authenticated and waiting for redirect
  if (token && player) {
    return <div className="min-h-screen bg-background" />;
  }

  return (
    <div className="min-h-[100dvh] w-full flex items-center justify-center bg-secondary relative overflow-hidden">
      {/* Decorative Wood Background */}
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{
        backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 10px, rgba(0,0,0,0.5) 10px, rgba(0,0,0,0.5) 12px)'
      }}></div>

      <div className="z-10 w-full max-w-md p-4">
        {/* Sign Board Header */}
        <div className="bg-[#8b5a2b] border-8 border-[#5c3a21] p-4 text-center mb-[-16px] relative z-20 shadow-lg transform rotate-[-2deg]">
          <h1 className="text-5xl text-white font-bold drop-shadow-md tracking-widest">FARMCITY</h1>
        </div>

        {/* Hanging Chains */}
        <div className="flex justify-between px-12 z-10 relative">
          <div className="w-2 h-8 bg-gray-400 border border-gray-600"></div>
          <div className="w-2 h-8 bg-gray-400 border border-gray-600"></div>
        </div>

        {/* Main Panel */}
        <div className="pixel-panel relative z-20">
          <div className="flex mb-6 border-b-4 border-foreground">
            <button
              type="button"
              className={`flex-1 py-2 text-2xl font-bold transition-colors ${isLogin ? 'bg-foreground text-background' : 'text-foreground hover:bg-muted'}`}
              onClick={() => setIsLogin(true)}
              data-testid="tab-login"
            >
              {t('login')}
            </button>
            <button
              type="button"
              className={`flex-1 py-2 text-2xl font-bold transition-colors ${!isLogin ? 'bg-foreground text-background' : 'text-foreground hover:bg-muted'}`}
              onClick={() => setIsLogin(false)}
              data-testid="tab-register"
            >
              {t('register')}
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-xl font-bold mb-2">{t('username')}</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="pixel-input"
                required
                minLength={3}
                data-testid="input-username"
              />
            </div>
            
            <div>
              <label className="block text-xl font-bold mb-2">{t('password')}</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pixel-input"
                required
                minLength={6}
                data-testid="input-password"
              />
            </div>

            {errorMsg && (
              <div className="bg-destructive/20 border-2 border-destructive text-destructive p-2 text-xl" data-testid="text-error">
                {errorMsg}
              </div>
            )}

            <button
              type="submit"
              disabled={loginMutation.isPending || registerMutation.isPending}
              className="pixel-btn w-full py-3 text-2xl"
              data-testid="button-submit"
            >
              {isLogin ? t('enter') : t('create_account')}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
