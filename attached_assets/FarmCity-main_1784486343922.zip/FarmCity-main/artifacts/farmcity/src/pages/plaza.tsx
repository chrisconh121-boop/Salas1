import { useState, useRef, useEffect, useCallback } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/contexts/auth-context';
import { useLanguage } from '@/contexts/language-context';
import { useGameSocket } from '@/hooks/use-game-socket';
import { IsometricCanvas } from '@/components/isometric-canvas';
import { useGetPlazaStatus, getGetPlazaStatusQueryKey, PlayerSummary } from '@workspace/api-client-react';
import { PixelAvatar } from '@/components/pixel-avatar';
import { X } from 'lucide-react';
import { OwnAvatarPanel } from '@/components/panels/own-avatar-panel';
import { OtherPlayerPanel } from '@/components/panels/other-player-panel';
import { WorldObjectPanel, WorldObjectType } from '@/components/panels/world-object-panel';

type PanelState =
  | { kind: 'self' }
  | { kind: 'player'; player: PlayerSummary }
  | { kind: 'object'; type: WorldObjectType }
  | null;

// ── Nav button ─────────────────────────────────────────────────────────────────
interface NavBtnProps {
  emoji: string;
  label: string;
  badge?: number;
  onClick?: () => void;
  active?: boolean;
}
function NavBtn({ emoji, label, badge, onClick, active }: NavBtnProps) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center justify-center gap-1 flex-1 py-3 active:opacity-70 transition-opacity"
      style={{
        borderTop: active ? '3px solid #F5C518' : '3px solid transparent',
      }}
    >
      <div className="relative">
        <span className="text-2xl leading-none select-none">{emoji}</span>
        {badge != null && badge > 0 && (
          <div
            className="absolute -top-1 -right-2 w-4 h-4 rounded-full flex items-center justify-center"
            style={{ background: '#E53935', border: '1px solid #B71C1C' }}
          >
            <span className="font-['VT323'] text-white leading-none" style={{ fontSize: 9 }}>
              {badge > 9 ? '9+' : badge}
            </span>
          </div>
        )}
      </div>
      <span
        className="font-['VT323'] text-xs leading-none"
        style={{ color: active ? '#F5C518' : 'rgba(255,255,255,0.75)' }}
      >
        {label}
      </span>
    </button>
  );
}

// ── Chat history drawer ────────────────────────────────────────────────────────
interface ChatDrawerProps {
  open: boolean;
  onClose: () => void;
  messages: Array<{ username: string; message: string; avatarShirtColor?: string }>;
}
function ChatDrawer({ open, onClose, messages }: ChatDrawerProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (open && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [open, messages]);

  return (
    <div
      className="absolute left-0 right-0 bottom-0 z-30 transition-transform duration-200"
      style={{
        transform: open ? 'translateY(0)' : 'translateY(100%)',
        maxHeight: '55vh',
        display: 'flex',
        flexDirection: 'column',
        background: 'rgba(8,4,1,0.96)',
        borderTop: '3px solid #3D2010',
      }}
    >
      <div
        className="flex items-center justify-between px-3 py-2 font-['VT323'] text-white text-base"
        style={{ borderBottom: '2px solid #2A1A0A' }}
      >
        <span>Chat General</span>
        <button onClick={onClose} className="opacity-70 active:opacity-100">
          <X size={18} />
        </button>
      </div>
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-3 space-y-2"
        style={{ scrollbarWidth: 'none' }}
      >
        {messages.length === 0 && (
          <p
            className="text-center font-['VT323'] text-base"
            style={{ color: 'rgba(255,255,255,0.35)' }}
          >
            Sin mensajes aún.
          </p>
        )}
        {messages.map((msg, i) => (
          <div key={i} className="flex flex-col mb-1">
            <span
              className="font-['VT323'] text-xs mb-0.5"
              style={{ color: '#D4A96A' }}
            >
              {msg.username}
            </span>
            <div
              className="px-2 py-1 font-['VT323'] text-base text-white break-words"
              style={{
                background: 'rgba(255,255,255,0.08)',
                border: '2px solid rgba(255,255,255,0.12)',
                borderLeftColor: msg.avatarShirtColor ?? '#F5C518',
                borderLeftWidth: 3,
              }}
            >
              {msg.message}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Main page ──────────────────────────────────────────────────────────────────
export default function Plaza() {
  const [, setLocation] = useLocation();
  const { t, language, setLanguage } = useLanguage();
  const { token, player, logout } = useAuth();

  const { players, messages, move, chat } = useGameSocket(token);
  const { data: plazaStatus } = useGetPlazaStatus({
    query: { enabled: !!token, refetchInterval: 10000, queryKey: getGetPlazaStatusQueryKey() },
  });

  const [chatMsg, setChatMsg] = useState('');
  const [chatOpen, setChatOpen] = useState(false);
  const [activeNav, setActiveNav] = useState<string | null>(null);
  const chatInputRef = useRef<HTMLInputElement>(null);

  // Floating panel state
  const [openPanel, setOpenPanel] = useState<PanelState>(null);
  const closePanel = useCallback(() => setOpenPanel(null), []);

  const handleClickSelf   = useCallback(() => setOpenPanel({ kind: 'self' }), []);
  const handleClickPlayer = useCallback((p: PlayerSummary) => setOpenPanel({ kind: 'player', player: p }), []);
  const handleClickObject = useCallback((type: WorldObjectType) => setOpenPanel({ kind: 'object', type }), []);

  useEffect(() => {
    if (!token || !player) {
      setLocation('/');
    } else if (!player.avatar) {
      setLocation('/avatar');
    }
  }, [token, player, setLocation]);

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (chatMsg.trim()) {
      chat(chatMsg.trim());
      setChatMsg('');
    }
    // Always blur after submit so keyboard closes on mobile
    chatInputRef.current?.blur();
  };

  // Close keyboard when player taps canvas to move
  const handleCanvasTap = useCallback(() => {
    chatInputRef.current?.blur();
  }, []);

  const handleLogout = () => {
    logout();
    setLocation('/');
  };

  if (!player || !player.avatar) return null;

  const onlineCount = plazaStatus?.onlineCount ?? Object.keys(players).length + 1;
  // Fake notification count for requests — hook up real data later
  const requestsBadge = 0;

  return (
    <div className="w-full h-[100dvh] flex flex-col overflow-hidden" style={{ background: '#0a0f14' }}>

      {/* ── Game canvas — fills all available space ─────────────────────────── */}
      <div className="relative flex-1 overflow-hidden" onPointerDown={handleCanvasTap}>
        <IsometricCanvas
          localPlayerId={player.id}
          localAvatar={player.avatar}
          localUsername={player.username}
          players={players}
          messages={messages}
          onMove={move}
          onClickSelf={handleClickSelf}
          onClickPlayer={handleClickPlayer}
          onClickObject={handleClickObject}
        />

        {/* ── Online badge — top right ──────────────────────────────────────── */}
        <div
          className="absolute top-3 right-3 z-10 flex items-center gap-1.5 px-2 py-1.5"
          style={{
            background: 'rgba(0,0,0,0.72)',
            border: '2px solid #2E7D32',
          }}
        >
          <span className="w-2 h-2 rounded-full bg-green-400 block" />
          <span className="font-['VT323'] text-white text-sm leading-none">
            {onlineCount} conectados
          </span>
        </div>

        {/* ── My avatar — top left (tap to open own panel) ─────────────────── */}
        <button
          onClick={handleClickSelf}
          className="absolute top-3 left-3 z-10 flex items-center gap-2 px-2 py-1.5 active:opacity-70"
          style={{
            background: 'rgba(0,0,0,0.72)',
            border: '2px solid #3D2010',
          }}
        >
          <div className="w-7 h-7 overflow-hidden">
            <PixelAvatar
              skinColor={player.avatar.skinColor}
              hairColor={player.avatar.hairColor}
              shirtColor={player.avatar.shirtColor}
              pantsColor={player.avatar.pantsColor}
              scale={2}
            />
          </div>
          <span className="font-['VT323'] text-white text-sm leading-none">{player.username}</span>
        </button>

        {/* ── Floating panels ───────────────────────────────────────────────── */}
        {openPanel?.kind === 'self' && player.avatar && (
          <OwnAvatarPanel username={player.username} avatar={player.avatar} onClose={closePanel} />
        )}
        {openPanel?.kind === 'player' && (
          <OtherPlayerPanel player={openPanel.player} onClose={closePanel} />
        )}
        {openPanel?.kind === 'object' && (
          <WorldObjectPanel objectType={openPanel.type} onClose={closePanel} />
        )}

        {/* ── Chat history drawer (slides up from bottom of canvas) ─────────── */}
        <ChatDrawer
          open={chatOpen}
          onClose={() => setChatOpen(false)}
          messages={messages}
        />
      </div>

      {/* ── Chat input bar ─────────────────────────────────────────────────── */}
      <form
        onSubmit={handleSendChat}
        className="flex items-center gap-2 px-3 py-2 shrink-0"
        style={{
          background: 'rgba(6,3,1,0.97)',
          borderTop: '2px solid #2A1A0A',
        }}
      >
        {/* Tap bubble to open history */}
        <button
          type="button"
          onClick={() => setChatOpen(v => !v)}
          className="text-lg leading-none shrink-0 active:opacity-70"
          style={{ marginRight: 2 }}
        >
          💬
        </button>
        <input
          ref={chatInputRef}
          type="text"
          value={chatMsg}
          onChange={e => setChatMsg(e.target.value)}
          onFocus={() => setChatOpen(false)}
          className="flex-1 bg-transparent font-['VT323'] text-white text-base outline-none placeholder:text-white/35"
          style={{
            background: 'rgba(255,255,255,0.07)',
            border: '2px solid rgba(255,255,255,0.15)',
            padding: '6px 10px',
          }}
          placeholder="Decir..."
          maxLength={100}
        />
        <button
          type="submit"
          disabled={!chatMsg.trim()}
          className="w-9 h-9 shrink-0 flex items-center justify-center text-base active:opacity-70 disabled:opacity-30"
          style={{
            background: chatMsg.trim() ? '#1B5E20' : '#111',
            border: '2px solid #2E7D32',
            transition: 'background 0.15s',
          }}
        >
          ▶
        </button>
      </form>

      {/* ── Bottom navigation ──────────────────────────────────────────────── */}
      <div
        className="flex items-stretch shrink-0"
        style={{
          background: 'rgba(8,4,1,0.97)',
          borderTop: '3px solid #3D2010',
          paddingBottom: 'env(safe-area-inset-bottom, 0px)',
        }}
      >
        <NavBtn
          emoji="🏠"
          label="Crear Sala"
          active={activeNav === 'sala'}
          onClick={() => setActiveNav(activeNav === 'sala' ? null : 'sala')}
        />
        <NavBtn
          emoji="🎒"
          label="Inventario"
          active={activeNav === 'inv'}
          onClick={() => setActiveNav(activeNav === 'inv' ? null : 'inv')}
        />
        <NavBtn
          emoji="📬"
          label="Solicitudes"
          badge={requestsBadge}
          active={activeNav === 'req'}
          onClick={() => setActiveNav(activeNav === 'req' ? null : 'req')}
        />
        <NavBtn
          emoji="⚙️"
          label="Ajustes"
          active={activeNav === 'cfg'}
          onClick={() => {
            setActiveNav(activeNav === 'cfg' ? null : 'cfg');
          }}
        />
      </div>

      {/* ── Settings mini-panel (replaces old top bar controls) ────────────── */}
      {activeNav === 'cfg' && (
        <div
          className="absolute bottom-28 left-0 right-0 mx-4 z-40 p-3 flex flex-col gap-3"
          style={{
            background: 'rgba(8,4,1,0.97)',
            border: '3px solid #3D2010',
          }}
        >
          <div className="flex items-center justify-between">
            <span className="font-['VT323'] text-white text-base">Idioma</span>
            <div className="flex" style={{ border: '2px solid #3D2010' }}>
              {(['es', 'pt'] as const).map(lang => (
                <button
                  key={lang}
                  onClick={() => setLanguage(lang)}
                  className="px-3 py-1 font-['VT323'] text-base uppercase"
                  style={{
                    background: language === lang ? '#3D2010' : 'transparent',
                    color: language === lang ? '#F5C518' : 'rgba(255,255,255,0.6)',
                  }}
                >
                  {lang.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="w-full py-2 font-['VT323'] text-base text-center active:opacity-70"
            style={{
              background: '#7F1D1D',
              border: '2px solid #991B1B',
              color: '#FCA5A5',
            }}
          >
            Cerrar Sesión
          </button>
        </div>
      )}

    </div>
  );
}
