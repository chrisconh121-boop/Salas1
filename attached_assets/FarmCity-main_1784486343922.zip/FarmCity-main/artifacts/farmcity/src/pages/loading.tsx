import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { useLanguage } from '@/contexts/language-context';

export default function Loading() {
  const [, setLocation] = useLocation();
  const { t } = useLanguage();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          setLocation('/home'); // Change to /home, so / is loading, wait no, requirements say /loading is loading, redirects to /
          return 100;
        }
        return p + 5;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [setLocation]);

  useEffect(() => {
    if (progress === 100) {
      setLocation('/');
    }
  }, [progress, setLocation]);

  return (
    <div className="min-h-[100dvh] w-full flex flex-col items-center justify-center bg-primary overflow-hidden relative">
      {/* Background Pixel Art Pattern (simple dots) */}
      <div className="absolute inset-0 opacity-20 pointer-events-none" style={{
        backgroundImage: 'radial-gradient(circle, #fff 2px, transparent 2px)',
        backgroundSize: '32px 32px'
      }}></div>
      
      <div className="z-10 flex flex-col items-center gap-8">
        <h1 className="text-6xl text-white tracking-widest drop-shadow-lg font-bold">
          FARMCITY
        </h1>
        
        <div className="w-64 h-8 bg-card border-4 border-foreground p-1">
          <div 
            className="h-full bg-accent transition-all duration-100 ease-linear"
            style={{ width: `${progress}%` }}
          />
        </div>
        
        <p className="text-white text-2xl animate-pulse">
          {t('loading')}
        </p>
      </div>
    </div>
  );
}
