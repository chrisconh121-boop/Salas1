import { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'es' | 'pt';

type Translations = Record<Language, Record<string, string>>;

const translations: Translations = {
  es: {
    loading: 'Cargando...',
    login: 'Entrar',
    register: 'Crear cuenta',
    username: 'Usuario',
    password: 'Contraseña',
    enter: 'Entrar al pueblo',
    create_account: 'Registrarse',
    avatar_creator: 'Creador de Personaje',
    skin_color: 'Piel',
    hair_color: 'Color de Pelo',
    hair_style: 'Peinado',
    shirt_color: 'Camisa',
    pants_color: 'Pantalón',
    hat: 'Sombrero (Opcional)',
    accessory: 'Accesorio (Opcional)',
    finish_avatar: 'Ir a la Plaza',
    plaza_title: 'Plaza Central',
    chat_placeholder: 'Escribe un mensaje...',
    send: 'Enviar',
    online_players: 'Jugadores en línea',
    messages_24h: 'Mensajes (24h)',
    logout: 'Salir',
    none: 'Ninguno',
    error_login: 'Usuario o contraseña incorrectos',
    error_register: 'Error al registrar',
    error_avatar: 'Error al guardar el avatar',
  },
  pt: {
    loading: 'Carregando...',
    login: 'Entrar',
    register: 'Criar conta',
    username: 'Usuário',
    password: 'Senha',
    enter: 'Entrar na vila',
    create_account: 'Cadastrar',
    avatar_creator: 'Criador de Personagem',
    skin_color: 'Pele',
    hair_color: 'Cor do Cabelo',
    hair_style: 'Penteado',
    shirt_color: 'Camisa',
    pants_color: 'Calça',
    hat: 'Chapéu (Opcional)',
    accessory: 'Acessório (Opcional)',
    finish_avatar: 'Ir para a Praça',
    plaza_title: 'Praça Central',
    chat_placeholder: 'Escreva uma mensagem...',
    send: 'Enviar',
    online_players: 'Jogadores online',
    messages_24h: 'Mensagens (24h)',
    logout: 'Sair',
    none: 'Nenhum',
    error_login: 'Usuário ou senha incorretos',
    error_register: 'Erro ao registrar',
    error_avatar: 'Erro ao salvar o avatar',
  }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('es');

  const t = (key: string) => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
