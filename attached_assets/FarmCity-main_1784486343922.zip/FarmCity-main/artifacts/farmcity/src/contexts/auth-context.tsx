import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Player } from '@workspace/api-client-react';
import { setAuthTokenGetter } from '@workspace/api-client-react';

const TOKEN_KEY = 'farmcity_token';

interface AuthContextType {
  token: string | null;
  player: Player | null;
  setToken: (token: string | null) => void;
  setPlayer: (player: Player | null) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Register the getter ONCE — always reads the latest value from localStorage
// so it's never stale regardless of React render timing.
setAuthTokenGetter(() => localStorage.getItem(TOKEN_KEY));

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setTokenState] = useState<string | null>(() => {
    return localStorage.getItem(TOKEN_KEY);
  });
  const [player, setPlayer] = useState<Player | null>(null);

  const setToken = (newToken: string | null) => {
    if (newToken) {
      localStorage.setItem(TOKEN_KEY, newToken);
    } else {
      localStorage.removeItem(TOKEN_KEY);
    }
    setTokenState(newToken);
  };

  const logout = () => {
    localStorage.removeItem(TOKEN_KEY);
    setTokenState(null);
    setPlayer(null);
  };

  return (
    <AuthContext.Provider value={{ token, player, setToken, setPlayer, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

// Keep the useEffect-free version — no cleanup needed since getter reads localStorage live.

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
