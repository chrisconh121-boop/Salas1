import { PanelBackdrop } from './panel-backdrop';
import { Avatar } from '@workspace/api-client-react';

// ── Shared pixel-art panel styles ─────────────────────────────────────────────
const BORDER = '4px solid #3D2010';
const BTN_BORDER = '2px solid #3D2010';

interface OwnAvatarPanelProps {
  username: string;
  avatar: Avatar;
  onClose: () => void;
}

function StatBar({ value, max, color }: { value: number; max: number; color: string }) {
  return (
    <div
      className="flex-1 h-3 overflow-hidden"
      style={{ background: '#E8D5AA', border: '1px solid #3D2010' }}
    >
      <div
        className="h-full"
        style={{ width: `${Math.round((value / max) * 100)}%`, background: color }}
      />
    </div>
  );
}

const ACTIONS = [
  { emoji: '🏡', label: 'Mi Granja' },
  { emoji: '🎒', label: 'Inventario' },
  { emoji: '👗', label: 'Cambiar ropa' },
  { emoji: '💃', label: 'Bailar' },
  { emoji: '😄', label: 'Emociones' },
  { emoji: '🪑', label: 'Sentarse' },
  { emoji: '📷', label: 'Fotografía' },
  { emoji: '⚙️', label: 'Config.' },
] as const;

export function OwnAvatarPanel({ username, avatar, onClose }: OwnAvatarPanelProps) {
  return (
    <PanelBackdrop onClose={onClose}>
      <div style={{ border: BORDER, background: '#FFF8E7' }}>

        {/* Header */}
        <div
          className="flex items-center justify-between px-3 py-2"
          style={{ background: '#7A4F1E', borderBottom: BORDER }}
        >
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-400" />
            <span className="font-['VT323'] text-white text-xl tracking-widest uppercase">
              {username}
            </span>
          </div>
          <button
            onClick={onClose}
            className="font-['VT323'] text-white text-xl leading-none hover:text-yellow-300 transition-colors px-1"
            style={{ border: '2px solid rgba(255,255,255,0.4)', minWidth: 24, textAlign: 'center' }}
          >
            ✕
          </button>
        </div>

        {/* Identity row */}
        <div
          className="flex items-center gap-4 px-4 py-3"
          style={{ borderBottom: '3px solid #D4A96A', background: '#FFFDF5' }}
        >
          {/* Avatar swatch from real colors */}
          <div
            className="flex-shrink-0 flex items-center justify-center"
            style={{ width: 56, height: 56, border: '3px solid #3D2010', background: '#C8E6B0' }}
          >
            <svg width="48" height="48" viewBox="0 0 16 16" style={{ imageRendering: 'pixelated' }}>
              {/* Shoes */}
              <rect x="5" y="14" width="2" height="1" fill="#2A2A2A" />
              <rect x="9" y="14" width="2" height="1" fill="#2A2A2A" />
              {/* Pants */}
              <rect x="5" y="10" width="3" height="5" fill={avatar.pantsColor} />
              <rect x="8" y="10" width="3" height="5" fill={avatar.pantsColor} />
              {/* Shirt + Arms */}
              <rect x="4" y="6" width="8" height="5" fill={avatar.shirtColor} />
              <rect x="2" y="6" width="2" height="4" fill={avatar.shirtColor} />
              <rect x="12" y="6" width="2" height="4" fill={avatar.shirtColor} />
              {/* Hands */}
              <rect x="2" y="10" width="2" height="1" fill={avatar.skinColor} />
              <rect x="12" y="10" width="2" height="1" fill={avatar.skinColor} />
              {/* Neck + Head */}
              <rect x="7" y="5" width="2" height="1" fill={avatar.skinColor} />
              <rect x="5" y="1" width="6" height="5" fill={avatar.skinColor} />
              {/* Hair */}
              <rect x="5" y="1" width="6" height="2" fill={avatar.hairColor} />
              <rect x="5" y="1" width="1" height="3" fill={avatar.hairColor} />
              {/* Eyes */}
              <rect x="6" y="3" width="1" height="1" fill="#111" />
              <rect x="9" y="3" width="1" height="1" fill="#111" />
            </svg>
          </div>

          <div className="flex flex-col gap-0.5 flex-1">
            <span className="font-['VT323'] text-xl text-[#3D2010] leading-tight">{username.toUpperCase()}</span>
            <div className="flex items-center gap-1">
              <span className="font-['VT323'] text-base text-[#7A4F1E]">Nivel</span>
              <span className="font-['VT323'] text-xl text-[#3D2010] leading-tight">1</span>
            </div>
            <span className="font-['VT323'] text-sm text-[#5C7A3A]">🌾 Granjero</span>
          </div>

          <div className="flex flex-col items-end gap-1">
            <span className="font-['VT323'] text-xs text-[#7A4F1E]">EXP</span>
            <div className="w-14 h-2" style={{ background: '#E8D5AA', border: '1px solid #3D2010' }}>
              <div className="h-full" style={{ width: '30%', background: '#F5A623' }} />
            </div>
            <span className="font-['VT323'] text-xs text-[#7A4F1E]">300/1000</span>
          </div>
        </div>

        {/* Stats */}
        <div
          className="px-4 py-3 flex flex-col gap-2"
          style={{ borderBottom: '3px solid #D4A96A', background: '#FFFDF5' }}
        >
          <div className="flex items-center gap-2">
            <span className="text-sm w-4">❤️</span>
            <span className="font-['VT323'] text-sm text-[#7A4F1E] w-8">Vida</span>
            <StatBar value={100} max={100} color="#E74C3C" />
            <span className="font-['VT323'] text-xs text-[#7A4F1E] w-14 text-right">100/100</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm w-4">🪙</span>
            <span className="font-['VT323'] text-sm text-[#7A4F1E] w-8">Oro</span>
            <span className="font-['VT323'] text-lg text-[#C5A028] flex-1">0</span>
            <span className="text-xs">💎</span>
            <span className="font-['VT323'] text-lg text-[#9B59B6]">0</span>
          </div>
        </div>

        {/* Action grid */}
        <div className="p-3 grid grid-cols-2 gap-2">
          {ACTIONS.map(({ emoji, label }) => (
            <button
              key={label}
              className="flex items-center gap-2 px-2 py-2 text-left hover:bg-[#F5E6C8] active:translate-y-px transition-all"
              style={{ border: BTN_BORDER, background: '#FFF8E7' }}
            >
              <span className="text-base leading-none">{emoji}</span>
              <span className="font-['VT323'] text-sm text-[#3D2010] leading-tight">{label}</span>
            </button>
          ))}
        </div>

        {/* Close button */}
        <div className="px-3 pb-3">
          <button
            onClick={onClose}
            className="w-full py-2 font-['VT323'] text-base text-white tracking-widest uppercase hover:opacity-90 active:translate-y-px transition-all"
            style={{ background: '#3D2010', border: '2px solid #1A0A02' }}
          >
            Cerrar panel
          </button>
        </div>
      </div>
    </PanelBackdrop>
  );
}
