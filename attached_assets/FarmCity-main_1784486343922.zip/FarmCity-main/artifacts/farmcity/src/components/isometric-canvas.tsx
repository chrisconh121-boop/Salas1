import { useEffect, useRef, useCallback } from 'react';
import { PlayerSummary, Avatar } from '@workspace/api-client-react';

// ─── Constants ───────────────────────────────────────────────────────────────
const TILE_W = 64;
const TILE_H = 32;
const MAP_SIZE = 20;
const WALK_SPEED = 5;   // tiles / second
const CAM_LERP  = 6;    // camera smoothing factor

// ─── Coordinate helpers ───────────────────────────────────────────────────────
function isoToScreen(x: number, y: number) {
  return {
    sx: (x - y) * (TILE_W / 2),
    sy: (x + y) * (TILE_H / 2),
  };
}

function screenToIso(sx: number, sy: number) {
  return {
    x: (sx / (TILE_W / 2) + sy / (TILE_H / 2)) / 2,
    y: (sy / (TILE_H / 2) - sx / (TILE_W / 2)) / 2,
  };
}

// ─── Map layout ──────────────────────────────────────────────────────────────
// Obstacle positions (trees + fountain) — expand here to add walls / furniture
const OBSTACLE_COORDS: [number, number][] = [
  // Fountain centre (3×3)
  [9, 9], [9, 10], [9, 11],
  [10, 9], [10, 10], [10, 11],
  [11, 9], [11, 10], [11, 11],
  // Trees scattered around the plaza
  [1, 1], [2, 1], [1, 2],
  [18, 1], [17, 1], [18, 2],
  [1, 18], [2, 18], [1, 17],
  [18, 18], [17, 18], [18, 17],
  [0, 9], [0, 10],
  [19, 9], [19, 10],
  [9, 0], [10, 0],
  [9, 19], [10, 19],
  [4, 4], [15, 4], [4, 15], [15, 15],
];

const OBSTACLES = new Set(OBSTACLE_COORDS.map(([x, y]) => `${x},${y}`));

const TREE_SET: [number, number][] = OBSTACLE_COORDS.filter(
  ([x, y]) => !(x >= 9 && x <= 11 && y >= 9 && y <= 11)
);

function getTileColor(x: number, y: number): string {
  // Stone square around fountain
  if (x >= 7 && x <= 13 && y >= 7 && y <= 13) return '#C8C8C8';
  // Diagonal stone paths
  if (x === y || x + y === MAP_SIZE - 1) return '#D4B88A';
  return (x + y) % 2 === 0 ? '#7DC95E' : '#6BBF50';
}

// ─── A* pathfinding ───────────────────────────────────────────────────────────
function aStar(
  start: { x: number; y: number },
  goal:  { x: number; y: number },
  blocked: Set<string>,
  size: number,
): { x: number; y: number }[] {
  const key = (x: number, y: number) => `${x},${y}`;
  const h   = (x: number, y: number) => Math.abs(x - goal.x) + Math.abs(y - goal.y);

  type Node = { x: number; y: number; g: number; f: number };
  const open    = new Map<string, Node>();
  const came    = new Map<string, string | null>();
  const gScore  = new Map<string, number>();
  const closed  = new Set<string>();

  const sk = key(start.x, start.y);
  const gk = key(goal.x, goal.y);
  open.set(sk, { x: start.x, y: start.y, g: 0, f: h(start.x, start.y) });
  came.set(sk, null);
  gScore.set(sk, 0);

  while (open.size > 0) {
    // Pick lowest-f node
    let bk = ''; let bf = Infinity;
    for (const [k, n] of open) if (n.f < bf) { bf = n.f; bk = k; }

    if (bk === gk) {
      // Reconstruct
      const path: { x: number; y: number }[] = [];
      let k: string | null = gk;
      while (k && came.has(k)) {
        const [px, py] = k.split(',').map(Number);
        path.unshift({ x: px, y: py });
        k = came.get(k) ?? null;
      }
      return path.slice(1); // exclude start tile
    }

    const cur = open.get(bk)!;
    open.delete(bk);
    closed.add(bk);

    for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nx = cur.x + dx, ny = cur.y + dy;
      if (nx < 0 || ny < 0 || nx >= size || ny >= size) continue;
      const nk = key(nx, ny);
      if (closed.has(nk) || blocked.has(nk)) continue;
      const g = (gScore.get(bk) ?? Infinity) + 1;
      if (g < (gScore.get(nk) ?? Infinity)) {
        gScore.set(nk, g);
        open.set(nk, { x: nx, y: ny, g, f: g + h(nx, ny) });
        came.set(nk, bk);
      }
    }
  }
  return [];
}

// ─── Canvas draw helpers ──────────────────────────────────────────────────────
function drawDiamond(ctx: CanvasRenderingContext2D, sx: number, sy: number) {
  ctx.beginPath();
  ctx.moveTo(sx,              sy);
  ctx.lineTo(sx + TILE_W / 2, sy + TILE_H / 2);
  ctx.lineTo(sx,              sy + TILE_H);
  ctx.lineTo(sx - TILE_W / 2, sy + TILE_H / 2);
  ctx.closePath();
}

function drawTile(
  ctx: CanvasRenderingContext2D,
  sx: number, sy: number,
  x: number, y: number,
  target: { x: number; y: number } | null,
  highlightAge: number,
) {
  drawDiamond(ctx, sx, sy);

  const isTarget = target?.x === x && target?.y === y;
  if (isTarget && highlightAge < 2.5) {
    const pulse = 0.55 + 0.45 * Math.sin(highlightAge * 10);
    ctx.fillStyle = `rgba(255, 215, 40, ${pulse})`;
  } else {
    ctx.fillStyle = getTileColor(x, y);
  }
  ctx.fill();

  // Subtle border
  ctx.strokeStyle = 'rgba(0,0,0,0.10)';
  ctx.lineWidth = 0.5;
  ctx.stroke();

  // Thin 3-D left/right faces for depth perception
  const d = 5;
  // Right face
  ctx.beginPath();
  ctx.moveTo(sx,              sy + TILE_H);
  ctx.lineTo(sx + TILE_W / 2, sy + TILE_H / 2);
  ctx.lineTo(sx + TILE_W / 2, sy + TILE_H / 2 + d);
  ctx.lineTo(sx,              sy + TILE_H + d);
  ctx.closePath();
  ctx.fillStyle = 'rgba(0,0,0,0.10)';
  ctx.fill();
  // Left face
  ctx.beginPath();
  ctx.moveTo(sx,              sy + TILE_H);
  ctx.lineTo(sx - TILE_W / 2, sy + TILE_H / 2);
  ctx.lineTo(sx - TILE_W / 2, sy + TILE_H / 2 + d);
  ctx.lineTo(sx,              sy + TILE_H + d);
  ctx.closePath();
  ctx.fillStyle = 'rgba(0,0,0,0.18)';
  ctx.fill();
}

function drawTree(ctx: CanvasRenderingContext2D, sx: number, sy: number) {
  // Trunk
  ctx.fillStyle = '#7A4F1E';
  ctx.fillRect(sx - 4, sy - 22, 8, 18);
  // Foliage (layered pixel art)
  ctx.fillStyle = '#1E5C0A';
  ctx.fillRect(sx - 16, sy - 50, 32, 16);
  ctx.fillStyle = '#277010';
  ctx.fillRect(sx - 13, sy - 62, 26, 14);
  ctx.fillStyle = '#35921A';
  ctx.fillRect(sx - 9,  sy - 72, 18, 12);
  // Top highlight
  ctx.fillStyle = '#50C030';
  ctx.fillRect(sx - 4, sy - 70, 5, 5);
}

function drawFountain(ctx: CanvasRenderingContext2D, sx: number, sy: number, now: number) {
  // Base ring
  ctx.fillStyle = '#8E8E9A';
  ctx.beginPath(); ctx.ellipse(sx, sy + 8, 30, 13, 0, 0, Math.PI * 2); ctx.fill();
  // Water pool
  const wave = Math.sin(now / 800) * 0.15 + 0.85;
  ctx.fillStyle = `rgba(70, 150, 220, ${wave})`;
  ctx.beginPath(); ctx.ellipse(sx, sy + 2, 22, 10, 0, 0, Math.PI * 2); ctx.fill();
  // Pillar
  ctx.fillStyle = '#ABABBA';
  ctx.fillRect(sx - 5, sy - 32, 10, 32);
  // Top bowl
  ctx.fillStyle = '#8E8E9A';
  ctx.beginPath(); ctx.ellipse(sx, sy - 32, 14, 6, 0, 0, Math.PI * 2); ctx.fill();
  // Animated water top
  const shimmer = Math.sin(now / 600 + 1) * 0.3 + 0.7;
  ctx.fillStyle = `rgba(120, 200, 255, ${shimmer})`;
  ctx.beginPath(); ctx.ellipse(sx, sy - 32, 9, 4, 0, 0, Math.PI * 2); ctx.fill();
}

function drawBench(ctx: CanvasRenderingContext2D, sx: number, sy: number) {
  ctx.fillStyle = '#7A4F1E';
  ctx.fillRect(sx - 18, sy - 8, 36, 6);
  ctx.fillStyle = '#5C3810';
  ctx.fillRect(sx - 14, sy - 2, 5, 8);
  ctx.fillRect(sx + 9,  sy - 2, 5, 8);
}

function drawCharacter(
  ctx: CanvasRenderingContext2D,
  sx: number, sy: number,
  skin  = '#FDDBB4',
  shirt = '#3CB371',
  pants = '#4169E1',
  hair  = '#2C1503',
  name: string,
  bubble?: { text: string; alpha: number } | null,
) {
  const S = 3;
  const ox = sx - 8 * S;
  const oy = sy - 16 * S;

  // Shadow
  ctx.fillStyle = 'rgba(0,0,0,0.22)';
  ctx.beginPath(); ctx.ellipse(sx, sy, 11, 5, 0, 0, Math.PI * 2); ctx.fill();

  // Shoes
  ctx.fillStyle = '#2A2A2A';
  ctx.fillRect(ox + 5*S, oy + 14*S, 2*S, S);
  ctx.fillRect(ox + 9*S, oy + 14*S, 2*S, S);

  // Pants
  ctx.fillStyle = pants;
  ctx.fillRect(ox + 5*S, oy + 10*S, 3*S, 5*S);
  ctx.fillRect(ox + 8*S, oy + 10*S, 3*S, 5*S);

  // Shirt / body
  ctx.fillStyle = shirt;
  ctx.fillRect(ox + 4*S, oy + 6*S, 8*S, 5*S);

  // Arms
  ctx.fillRect(ox + 2*S, oy + 6*S, 2*S, 4*S);
  ctx.fillRect(ox + 12*S,oy + 6*S, 2*S, 4*S);

  // Hands
  ctx.fillStyle = skin;
  ctx.fillRect(ox + 2*S, oy + 10*S, 2*S, S);
  ctx.fillRect(ox + 12*S,oy + 10*S, 2*S, S);

  // Neck + head
  ctx.fillRect(ox + 7*S, oy + 5*S, 2*S, S);
  ctx.fillRect(ox + 5*S, oy +   S, 6*S, 5*S);

  // Hair
  ctx.fillStyle = hair;
  ctx.fillRect(ox + 5*S, oy +   S, 6*S, 2*S);
  ctx.fillRect(ox + 5*S, oy +   S,   S, 3*S);
  ctx.fillRect(ox + 11*S,oy +   S,   S, 2*S);

  // Eyes
  ctx.fillStyle = '#111';
  ctx.fillRect(ox + 6*S, oy + 3*S, S, S);
  ctx.fillRect(ox + 9*S, oy + 3*S, S, S);

  // Name tag
  ctx.font = 'bold 13px "VT323", monospace';
  ctx.textAlign = 'center';
  const tw = ctx.measureText(name).width;
  ctx.fillStyle = 'rgba(0,0,0,0.58)';
  ctx.fillRect(sx - tw / 2 - 3, oy - 22, tw + 6, 18);
  ctx.fillStyle = '#fff';
  ctx.fillText(name, sx, oy - 8);

  // ── Speech bubble ─────────────────────────────────────────────────────────
  if (bubble && bubble.alpha > 0.01) {
    const RAW = bubble.text;
    // Truncate long messages
    const txt  = RAW.length > 32 ? RAW.slice(0, 30) + '…' : RAW;
    const PAD  = 8;
    const TAIL = 6;

    ctx.save();
    ctx.globalAlpha = bubble.alpha;
    ctx.font = 'bold 13px "VT323", monospace';

    const textW = ctx.measureText(txt).width;
    const bw = textW + PAD * 2;
    const bh = 20;
    // Position: just above the name tag
    const bx = sx - bw / 2;
    const by = oy - 22 - bh - TAIL - 4;

    // White fill
    ctx.fillStyle = '#fff';
    ctx.fillRect(bx, by, bw, bh);

    // Coloured border (shirt colour)
    ctx.strokeStyle = shirt;
    ctx.lineWidth = 2;
    ctx.strokeRect(bx, by, bw, bh);

    // Triangle tail pointing down to name tag
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.moveTo(sx - TAIL, by + bh);
    ctx.lineTo(sx + TAIL, by + bh);
    ctx.lineTo(sx,        by + bh + TAIL);
    ctx.closePath();
    ctx.fill();

    // Tail border (only the two slanted edges, so it looks clean)
    ctx.strokeStyle = shirt;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(sx - TAIL, by + bh);
    ctx.lineTo(sx,        by + bh + TAIL);
    ctx.lineTo(sx + TAIL, by + bh);
    ctx.stroke();

    // Text
    ctx.fillStyle = '#111';
    ctx.textAlign = 'center';
    ctx.fillText(txt, sx, by + bh - 5);

    ctx.restore();
  }
}

// ─── Bench tiles (non-blocking, clickable) ───────────────────────────────────
const BENCH_TILES = new Set(['7,10', '13,10', '10,7', '10,13']);

// ─── Component ────────────────────────────────────────────────────────────────
const BUBBLE_DURATION = 5000; // ms total
const BUBBLE_FADE_AT  = 3500; // ms — start fading after this

interface ChatMsg { username: string; message: string; avatarShirtColor?: string }

interface IsometricCanvasProps {
  localPlayerId:  number;
  localAvatar:    Avatar | undefined;
  localUsername?: string;
  players:        Record<number, PlayerSummary>;
  messages?:      ChatMsg[];
  onMove:         (x: number, y: number) => void;
  onClickSelf?:   () => void;
  onClickPlayer?: (player: PlayerSummary) => void;
  onClickObject?: (type: 'fountain' | 'tree' | 'bench') => void;
}

export function IsometricCanvas({
  localPlayerId, localAvatar, localUsername, players, messages, onMove,
  onClickSelf, onClickPlayer, onClickObject,
}: IsometricCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // All mutable animation state lives in refs → no React re-renders per frame
  const posRef           = useRef({ x: 5.0, y: 5.0 });   // sub-tile float position
  const pathRef          = useRef<{ x: number; y: number }[]>([]);
  const camRef           = useRef({ x: 0.0, y: 0.0 });
  const targetTileRef    = useRef<{ x: number; y: number } | null>(null);
  const highlightTimeRef = useRef(0);

  // Speech bubbles: username → { text, startTime }
  const bubblesRef = useRef<Map<string, { text: string; startTime: number }>>(new Map());

  // Mirror latest props into refs so the render loop always has fresh data
  const playersRef        = useRef(players);
  const localAvatarRef    = useRef(localAvatar);
  const localUsernameRef  = useRef(localUsername);
  const onMoveRef         = useRef(onMove);
  const onClickSelfRef    = useRef(onClickSelf);
  const onClickPlayerRef  = useRef(onClickPlayer);
  const onClickObjectRef  = useRef(onClickObject);
  useEffect(() => { playersRef.current       = players;       }, [players]);
  useEffect(() => { localAvatarRef.current   = localAvatar;   }, [localAvatar]);
  useEffect(() => { localUsernameRef.current = localUsername; }, [localUsername]);
  useEffect(() => { onMoveRef.current        = onMove;        }, [onMove]);
  useEffect(() => { onClickSelfRef.current   = onClickSelf;   }, [onClickSelf]);
  useEffect(() => { onClickPlayerRef.current = onClickPlayer; }, [onClickPlayer]);
  useEffect(() => { onClickObjectRef.current = onClickObject; }, [onClickObject]);

  // Update bubbles whenever a new message arrives
  useEffect(() => {
    if (!messages || messages.length === 0) return;
    const last = messages[messages.length - 1];
    bubblesRef.current.set(last.username, {
      text: `${last.username}: ${last.message}`,
      startTime: performance.now(),
    });
  }, [messages]);

  // ── Pointer → tile → A* ───────────────────────────────────────────────────
  const handlePointer = useCallback((clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect   = canvas.getBoundingClientRect();
    // Account for CSS scaling (canvas may be displayed smaller/larger than its pixel size)
    const cx = (clientX - rect.left) * (canvas.width  / rect.width);
    const cy = (clientY - rect.top)  * (canvas.height / rect.height);

    // Undo the camera transform applied in the render loop:
    //   ctx.translate(-cam.x, -cam.y + TILE_H * 2)
    const worldX = cx + camRef.current.x;
    const worldY = cy + camRef.current.y - TILE_H * 2;

    const { x: fx, y: fy } = screenToIso(worldX, worldY);
    const tx = Math.round(fx);
    const ty = Math.round(fy);

    if (tx < 0 || tx >= MAP_SIZE || ty < 0 || ty >= MAP_SIZE) return;

    // Always highlight the tapped tile
    targetTileRef.current    = { x: tx, y: ty };
    highlightTimeRef.current = performance.now();

    const sx = Math.round(posRef.current.x);
    const sy = Math.round(posRef.current.y);

    // ── Entity hit detection (priority: self → other player → object → move) ──

    // 1. Own avatar
    if (tx === sx && ty === sy) {
      onClickSelfRef.current?.();
      return;
    }

    // 2. Another player standing on that tile
    for (const p of Object.values(playersRef.current)) {
      if (p.posX == null || p.posY == null) continue;
      if (Math.round(p.posX) === tx && Math.round(p.posY) === ty) {
        onClickPlayerRef.current?.(p);
        return;
      }
    }

    // 3. Fountain (centre 3×3 obstacle block)
    if (tx >= 9 && tx <= 11 && ty >= 9 && ty <= 11) {
      onClickObjectRef.current?.('fountain');
      return;
    }

    // 4. Bench (non-blocking but clickable)
    if (BENCH_TILES.has(`${tx},${ty}`)) {
      onClickObjectRef.current?.('bench');
      return;
    }

    // 5. Tree (remaining obstacle tiles)
    if (OBSTACLES.has(`${tx},${ty}`)) {
      onClickObjectRef.current?.('tree');
      return;
    }

    // 6. Walk to tile
    if (sx === tx && sy === ty) return;
    const path = aStar({ x: sx, y: sy }, { x: tx, y: ty }, OBSTACLES, MAP_SIZE);
    if (path.length > 0) pathRef.current = path;
    // If no path found, character stays put (never gets stuck)
  }, []);

  // ── Attach click + touch events ────────────────────────────────────────────
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const onClick = (e: MouseEvent) => {
      e.preventDefault();
      handlePointer(e.clientX, e.clientY);
    };
    const onTouchEnd = (e: TouchEvent) => {
      e.preventDefault();
      const t = e.changedTouches[0];
      if (t) handlePointer(t.clientX, t.clientY);
    };

    canvas.addEventListener('click',    onClick);
    canvas.addEventListener('touchend', onTouchEnd, { passive: false });
    return () => {
      canvas.removeEventListener('click',    onClick);
      canvas.removeEventListener('touchend', onTouchEnd);
    };
  }, [handlePointer]);

  // ── Keyboard navigation (also uses A* for single steps) ───────────────────
  useEffect(() => {
    const DIRS: Record<string, [number, number]> = {
      ArrowUp:    [-1,  0],  w: [-1,  0],
      ArrowDown:  [ 1,  0],  s: [ 1,  0],
      ArrowLeft:  [ 0,  1],  a: [ 0,  1],
      ArrowRight: [ 0, -1],  d: [ 0, -1],
    };
    const onKey = (e: KeyboardEvent) => {
      const dir = DIRS[e.key];
      if (!dir) return;
      if (e.key.startsWith('Arrow')) e.preventDefault();

      const cx = Math.round(posRef.current.x);
      const cy = Math.round(posRef.current.y);
      const nx = Math.max(0, Math.min(MAP_SIZE - 1, cx + dir[0]));
      const ny = Math.max(0, Math.min(MAP_SIZE - 1, cy + dir[1]));
      if ((nx === cx && ny === cy) || OBSTACLES.has(`${nx},${ny}`)) return;

      targetTileRef.current    = { x: nx, y: ny };
      highlightTimeRef.current = performance.now();
      pathRef.current          = [{ x: nx, y: ny }];
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // ── Main animation / render loop (runs once, reads refs) ──────────────────
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Responsive canvas size via ResizeObserver
    const ro = new ResizeObserver(() => {
      const p = canvas.parentElement;
      if (p) { canvas.width = p.clientWidth; canvas.height = p.clientHeight; }
    });
    const parent = canvas.parentElement;
    if (parent) {
      ro.observe(parent);
      canvas.width  = parent.clientWidth;
      canvas.height = parent.clientHeight;
    }

    ctx.imageSmoothingEnabled = false;
    let last = performance.now();
    let animId: number;

    const loop = (now: number) => {
      const dt = Math.min((now - last) / 1000, 0.1); // cap at 100 ms
      last = now;

      // ── Walk along path ──────────────────────────────────────────────────
      if (pathRef.current.length > 0) {
        const next = pathRef.current[0];
        const dx   = next.x - posRef.current.x;
        const dy   = next.y - posRef.current.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const step = WALK_SPEED * dt;

        if (dist <= step) {
          // Arrived at this waypoint
          posRef.current = { x: next.x, y: next.y };
          pathRef.current = pathRef.current.slice(1);
          if (pathRef.current.length === 0) {
            // Final destination reached → notify server
            onMoveRef.current(next.x, next.y);
          }
        } else {
          posRef.current = {
            x: posRef.current.x + (dx / dist) * step,
            y: posRef.current.y + (dy / dist) * step,
          };
        }
      }

      // ── Camera lerp ──────────────────────────────────────────────────────
      const { sx: psx, sy: psy } = isoToScreen(posRef.current.x, posRef.current.y);
      const tcx  = psx - canvas.width  / 2;
      const tcy  = psy - canvas.height / 2;
      const lerp = 1 - Math.exp(-CAM_LERP * dt);
      camRef.current.x += (tcx - camRef.current.x) * lerp;
      camRef.current.y += (tcy - camRef.current.y) * lerp;

      // ── Clear ────────────────────────────────────────────────────────────
      ctx.fillStyle = '#5FA8C8';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.save();
      ctx.translate(-camRef.current.x, -camRef.current.y + TILE_H * 2);

      const highlightAge = (now - highlightTimeRef.current) / 1000;
      const targetTile   = targetTileRef.current;

      // ── Draw tiles in isometric depth order (diagonals, back→front) ──────
      for (let sum = 0; sum < MAP_SIZE * 2 - 1; sum++) {
        for (let x = 0; x <= sum; x++) {
          const y = sum - x;
          if (x >= MAP_SIZE || y >= MAP_SIZE) continue;
          const { sx, sy } = isoToScreen(x, y);
          drawTile(ctx, sx, sy, x, y, targetTile, highlightAge);
        }
      }

      // ── Collect entities for depth-sorted rendering ────────────────────
      type Entity = { depth: number; draw: () => void };
      const entities: Entity[] = [];

      // Trees
      for (const [tx, ty] of TREE_SET) {
        const { sx, sy } = isoToScreen(tx, ty);
        const depth = tx + ty;
        entities.push({ depth, draw: () => drawTree(ctx, sx, sy + TILE_H / 2) });
      }

      // Fountain (occupies centre 3×3; render at iso depth of centre tile)
      {
        const { sx, sy } = isoToScreen(10, 10);
        entities.push({
          depth: 20,
          draw:  () => drawFountain(ctx, sx, sy - TILE_H / 4, now),
        });
      }

      // Benches (non-blocking decoration)
      for (const [bx, by] of [[7, 10], [13, 10], [10, 7], [10, 13]] as [number, number][]) {
        const { sx, sy } = isoToScreen(bx, by);
        entities.push({ depth: bx + by, draw: () => drawBench(ctx, sx, sy + TILE_H / 2) });
      }

      // Helper: compute bubble alpha for a username, returns null if expired
      const getBubble = (username: string) => {
        const b = bubblesRef.current.get(username);
        if (!b) return null;
        const age = now - b.startTime;
        if (age >= BUBBLE_DURATION) {
          bubblesRef.current.delete(username);
          return null;
        }
        const alpha = age >= BUBBLE_FADE_AT
          ? 1 - (age - BUBBLE_FADE_AT) / (BUBBLE_DURATION - BUBBLE_FADE_AT)
          : 1;
        return { text: b.text, alpha };
      };

      // Local player
      const la = localAvatarRef.current;
      const localUname = localUsernameRef.current ?? '';
      const { sx: lsx, sy: lsy } = isoToScreen(posRef.current.x, posRef.current.y);
      const localBubble = getBubble(localUname);
      entities.push({
        depth: posRef.current.x + posRef.current.y,
        draw:  () => drawCharacter(
          ctx, lsx, lsy + TILE_H / 2,
          la?.skinColor, la?.shirtColor, la?.pantsColor, la?.hairColor, 'Tú',
          localBubble,
        ),
      });

      // Remote players
      for (const p of Object.values(playersRef.current)) {
        if (p.id === localPlayerId || p.posX == null || p.posY == null) continue;
        const { sx: rx, sy: ry } = isoToScreen(p.posX, p.posY);
        const depth = p.posX + p.posY;
        const pBubble = getBubble(p.username);
        entities.push({
          depth,
          draw: () => drawCharacter(
            ctx, rx, ry + TILE_H / 2,
            p.avatar?.skinColor, p.avatar?.shirtColor, p.avatar?.pantsColor, p.avatar?.hairColor,
            p.username,
            pBubble,
          ),
        });
      }

      entities.sort((a, b) => a.depth - b.depth);
      for (const e of entities) e.draw();

      ctx.restore();
      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(animId); ro.disconnect(); };
  }, [localPlayerId]); // intentionally stable — reads props via refs

  return (
    <div
      className="w-full h-full relative"
      style={{ touchAction: 'none' }}  // prevents browser scroll-swipe on mobile
    >
      <canvas
        ref={canvasRef}
        className="block w-full h-full cursor-pointer"
        data-testid="isometric-canvas"
      />
    </div>
  );
}
