import { useEffect, useRef, useState, useCallback } from 'react';
import { PlayerSummary, ChatMessage } from '@workspace/api-client-react';

export type SocketMessage = 
  | { type: "players_update"; players: PlayerSummary[] }
  | { type: "chat_message"; message: ChatMessage }
  | { type: "player_joined"; player: PlayerSummary }
  | { type: "player_left"; playerId: number }
  | { type: "player_moved"; playerId: number; posX: number; posY: number };

export function useGameSocket(token: string | null) {
  const [players, setPlayers] = useState<Record<number, PlayerSummary>>({});
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const socketRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (!token) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    // If running with Vite proxy, ws://HOST/ws is proxied to the API
    // We should use the host of the current page. If the API is served on the same host:
    const wsUrl = `${protocol}//${window.location.host}/ws?token=${token}`;
    
    const ws = new WebSocket(wsUrl);
    socketRef.current = ws;

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data) as SocketMessage;
        
        switch (data.type) {
          case 'players_update':
            setPlayers(prev => {
              const next = { ...prev };
              data.players.forEach(p => {
                next[p.id] = { ...next[p.id], ...p };
              });
              return next;
            });
            break;
          case 'player_joined':
            setPlayers(prev => ({ ...prev, [data.player.id]: data.player }));
            break;
          case 'player_left':
            setPlayers(prev => {
              const next = { ...prev };
              delete next[data.playerId];
              return next;
            });
            break;
          case 'player_moved':
            setPlayers(prev => {
              if (!prev[data.playerId]) return prev;
              return {
                ...prev,
                [data.playerId]: {
                  ...prev[data.playerId],
                  posX: data.posX,
                  posY: data.posY
                }
              };
            });
            break;
          case 'chat_message':
            setMessages(prev => [...prev.slice(-49), data.message]); // keep last 50
            break;
        }
      } catch (e) {
        console.error("Failed to parse socket message", e);
      }
    };

    return () => {
      ws.close();
    };
  }, [token]);

  const move = useCallback((posX: number, posY: number) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({ type: "move", posX, posY }));
    }
  }, []);

  const chat = useCallback((message: string) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({ type: "chat", message }));
    }
  }, []);

  return { players, messages, move, chat };
}
