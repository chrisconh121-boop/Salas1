import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { playersTable } from "./players";

export const avatarsTable = pgTable("avatars", {
  id: serial("id").primaryKey(),
  playerId: integer("player_id").notNull().references(() => playersTable.id).unique(),
  skinColor: text("skin_color").notNull(),
  hairColor: text("hair_color").notNull(),
  hairStyle: text("hair_style").notNull(),
  shirtColor: text("shirt_color").notNull(),
  pantsColor: text("pants_color").notNull(),
  hatStyle: text("hat_style"),
  accessory: text("accessory"),
});

export const insertAvatarSchema = createInsertSchema(avatarsTable).omit({ id: true });
export type InsertAvatar = z.infer<typeof insertAvatarSchema>;
export type Avatar = typeof avatarsTable.$inferSelect;
