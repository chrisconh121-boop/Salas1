import { pgTable, serial, integer, real } from "drizzle-orm/pg-core";
import { playersTable } from "./players";

export const playerPositionsTable = pgTable("player_positions", {
  id: serial("id").primaryKey(),
  playerId: integer("player_id").notNull().references(() => playersTable.id).unique(),
  posX: real("pos_x").notNull().default(0),
  posY: real("pos_y").notNull().default(0),
});

export type PlayerPosition = typeof playerPositionsTable.$inferSelect;
